<?php
namespace Aura\Base;

class Container {
    private $services = [];
    private $instances = [];

    public function register(array $services) {
        foreach ($services as $key => $service) {
            $this->services[$key] = $service;
        }
    }

    public function get($id) {
        if (!isset($this->instances[$id])) {
            if (!isset($this->services[$id])) {
                throw new \Exception("Service {$id} not found in container.");
            }
            $this->instances[$id] = new $this->services[$id]($this);
        }
        return $this->instances[$id];
    }
}