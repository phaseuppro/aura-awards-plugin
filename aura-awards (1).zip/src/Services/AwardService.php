<?php
namespace Aura\Services;

class AwardService {
    private $container;

    public function __construct($container) {
        $this->container = $container;
    }

    public function createAward($data) {
        return wp_insert_post([
            'post_type' => 'award',
            'post_title' => $data['title'],
            'post_content' => $data['description'],
            'post_status' => 'publish'
        ]);
    }

    public function getActiveAwards() {
        return get_posts([
            'post_type' => 'award',
            'post_status' => 'publish',
            'posts_per_page' => -1
        ]);
    }
}
