<?php
class Test_Aura_Voting_System extends WP_UnitTestCase {
    private $voting_system;
    private $test_user_id;
    private $test_submission_id;

    public function setUp(): void {
        parent::setUp();
        
        $this->voting_system = aura_voting_system();
        
        // Create test user
        $this->test_user_id = $this->factory->user->create(array(
            'role' => 'photographer'
        ));
        
        // Create test submission
        $this->test_submission_id = $this->factory->post->create(array(
            'post_type' => 'aura_submission',
            'post_author' => $this->test_user_id,
            'post_status' => 'pending'
        ));
    }

    public function test_vote_submission() {
        $votes = array(
            'light' => 8,
            'pose' => 7,
            'idea' => 9,
            'colors' => 8,
            'material' => 7,
            'emotion' => 9
        );

        $_POST['submission_id'] = $this->test_submission_id;
        $_POST['votes'] = $votes;
        $_POST['nonce'] = wp_create_nonce('aura_voting');

        // Set current user as admin
        wp_set_current_user(1);

        // Submit vote
        $result = $this->voting_system->handle_vote_submission();
        
        // Get saved votes
        $saved_votes = get_post_meta($this->test_submission_id, 'aura_votes', true);
        $total_points = get_post_meta($this->test_submission_id, 'aura_total_points', true);
        $badge_level = get_post_meta($this->test_submission_id, 'aura_badge_level', true);

        // Assertions
        $this->assertEquals($votes, $saved_votes);
        $this->assertEquals(80, $total_points);
        $this->assertEquals('gold', $badge_level);
        $this->assertEquals('publish', get_post_status($this->test_submission_id));
    }

    public function test_invalid_vote_values() {
        $votes = array(
            'light' => 15, // Invalid value > 10
            'pose' => -1,  // Invalid negative value
            'idea' => 9,
            'colors' => 8,
            'material' => 7,
            'emotion' => 9
        );

        $_POST['submission_id'] = $this->test_submission_id;
        $_POST['votes'] = $votes;
        $_POST['nonce'] = wp_create_nonce('aura_voting');

        wp_set_current_user(1);

        $this->voting_system->handle_vote_submission();
        $saved_votes = get_post_meta($this->test_submission_id, 'aura_votes', true);

        // Check if values were sanitized
        $this->assertEquals(10, $saved_votes['light']);
        $this->assertEquals(0, $saved_votes['pose']);
    }

    public function test_unauthorized_voting() {
        wp_set_current_user($this->test_user_id); // Set non-admin user

        $_POST['submission_id'] = $this->test_submission_id;
        $_POST['votes'] = array('light' => 8);
        $_POST['nonce'] = wp_create_nonce('aura_voting');

        $result = $this->voting_system->handle_vote_submission();
        
        $this->assertFalse($result->success);
        $this->assertEquals('Unauthorized access', $result->data);
    }

    public function tearDown(): void {
        wp_delete_post($this->test_submission_id, true);
        wp_delete_user($this->test_user_id);
        parent::tearDown();
    }
}
