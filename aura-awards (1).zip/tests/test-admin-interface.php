<?php
class Test_Aura_Admin_Interface extends WP_UnitTestCase {
    private $admin_interface;
    private $test_admin_id;
    private $test_submission_id;

    public function setUp(): void {
        parent::setUp();
        
        $this->admin_interface = aura_admin_interface();
        
        // Create test admin user
        $this->test_admin_id = $this->factory->user->create(array(
            'role' => 'administrator'
        ));

        // Create test submission
        $this->test_submission_id = $this->factory->post->create(array(
            'post_type' => 'aura_submission',
            'post_status' => 'pending'
        ));
    }

    public function test_admin_menu_creation() {
        wp_set_current_user($this->test_admin_id);
        
        $this->admin_interface->add_admin_menu();
        
        global $menu;
        $menu_exists = false;
        
        foreach ($menu as $item) {
            if ($item[0] === 'AURA AWARDS') {
                $menu_exists = true;
                break;
            }
        }
        
        $this->assertTrue($menu_exists);
    }

    public function test_settings_page() {
        ob_start();
        $this->admin_interface->render_settings_page();
        $output = ob_get_clean();
        
        $this->assertStringContainsString('AURA AWARDS Settings', $output);
        $this->assertStringContainsString('form', $output);
    }

    public function test_save_settings() {
        $_POST['aura_settings'] = array(
            'min_points_gold' => '85',
            'min_points_silver' => '75',
            'min_points_bronze' => '65',
            'credits_per_submission' => '1'
        );
        $_POST['_wpnonce'] = wp_create_nonce('aura_settings');

        $this->admin_interface->save_settings();
        
        $saved_settings = get_option('aura_settings');
        $this->assertEquals('85', $saved_settings['min_points_gold']);
        $this->assertEquals('75', $saved_settings['min_points_silver']);
        $this->assertEquals('65', $saved_settings['min_points_bronze']);
    }

    public function test_submissions_list() {
        ob_start();
        $this->admin_interface->render_submissions_page();
        $output = ob_get_clean();
        
        $this->assertStringContainsString('Manage Submissions', $output);
        $this->assertStringContainsString('submission-card', $output);
    }

    public function test_ajax_filter_submissions() {
        $_POST['category'] = 'maternity';
        $_POST['status'] = 'pending';
        $_POST['nonce'] = wp_create_nonce('aura_admin');
        
        wp_set_current_user($this->test_admin_id);
        
        ob_start();
        $this->admin_interface->filter_submissions();
        $response = json_decode(ob_get_clean());
        
        $this->assertTrue($response->success);
        $this->assertIsString($response->data);
    }

    public function test_export_rankings() {
        $_GET['format'] = 'csv';
        $_GET['nonce'] = wp_create_nonce('aura_admin');
        
        ob_start();
        $this->admin_interface->export_rankings();
        $output = ob_get_clean();
        
        $this->assertStringContainsString('Rank,Photographer,Points', $output);
    }

    public function tearDown(): void {
        wp_delete_post($this->test_submission_id, true);
        wp_delete_user($this->test_admin_id);
        delete_option('aura_settings');
        
        parent::tearDown();
    }
}
