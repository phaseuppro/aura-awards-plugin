<?php if (!defined('ABSPATH')) exit; ?>

<div class="aura-settings-wrapper">
    <form method="post" action="options.php">
        <?php settings_fields('aura_awards_options'); ?>
        
        <div class="settings-section">
            <h2>General Settings</h2>
            <table class="form-table">
                <tr>
                    <th scope="row">Enable Public Voting</th>
                    <td>
                        <input type="checkbox" name="aura_public_voting" value="1" <?php checked(get_option('aura_public_voting'), 1); ?>>
                    </td>
                </tr>
                <tr>
                    <th scope="row">Credits per Submission</th>
                    <td>
                        <input type="number" name="aura_submission_credits" value="<?php echo esc_attr(get_option('aura_submission_credits')); ?>">
                    </td>
                </tr>
                <tr>
                    <th scope="row">Maximum Submissions per User</th>
                    <td>
                        <input type="number" name="aura_max_submissions" value="<?php echo esc_attr(get_option('aura_max_submissions')); ?>">
                    </td>
                </tr>
            </table>
        </div>

        <div class="settings-section">
            <h2>Judging Settings</h2>
            <table class="form-table">
                <tr>
                    <th scope="row">Number of Judges Required</th>
                    <td>
                        <input type="number" name="aura_required_judges" value="<?php echo esc_attr(get_option('aura_required_judges')); ?>">
                    </td>
                </tr>
                <tr>
                    <th scope="row">Scoring System</th>
                    <td>
                        <select name="aura_scoring_system">
                            <option value="1-10" <?php selected(get_option('aura_scoring_system'), '1-10'); ?>>1-10 Scale</option>
                            <option value="1-5" <?php selected(get_option('aura_scoring_system'), '1-5'); ?>>1-5 Scale</option>
                            <option value="percentage" <?php selected(get_option('aura_scoring_system'), 'percentage'); ?>>Percentage</option>
                        </select>
                    </td>
                </tr>
            </table>
        </div>

        <div class="settings-section">
            <h2>Email Notifications</h2>
            <table class="form-table">
                <tr>
                    <th scope="row">Admin Email</th>
                    <td>
                        <input type="email" name="aura_admin_email" value="<?php echo esc_attr(get_option('aura_admin_email')); ?>">
                    </td>
                </tr>
                <tr>
                    <th scope="row">Notification Templates</th>
                    <td>
                        <textarea name="aura_submission_email" rows="5" cols="50" placeholder="Submission confirmation email template"><?php echo esc_textarea(get_option('aura_submission_email')); ?></textarea>
                    </td>
                </tr>
            </table>
        </div>

        <?php submit_button('Save Settings'); ?>
    </form>
</div>
