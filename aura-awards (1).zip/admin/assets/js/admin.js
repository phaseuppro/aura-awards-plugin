(function($) {
    'use strict';

    const AuraAdmin = {
        init: function() {
            this.initTabs();
            this.initFilters();
            this.initJudgingForm();
            this.initModals();
            this.initRankings();
            this.initExport();
        },

        initTabs: function() {
            $('.nav-tab-wrapper a').on('click', function(e) {
                e.preventDefault();
                const target = $(this).attr('href');
                
                $('.nav-tab').removeClass('nav-tab-active');
                $(this).addClass('nav-tab-active');
                
                $('.tab-content').removeClass('active');
                $(target).addClass('active');
            });
        },

        initFilters: function() {
            $('#apply-filters').on('click', function() {
                const category = $('#category-filter').val();
                const status = $('#status-filter').val();
                const date = $('#date-filter').val();

                $.ajax({
                    url: auraAdmin.ajaxUrl,
                    data: {
                        action: 'filter_submissions',
                        nonce: auraAdmin.nonce,
                        category: category,
                        status: status,
                        date: date
                    },
                    success: function(response) {
                        $('.aura-submissions-grid').html(response.data);
                    }
                });
            });
        },

        initJudgingForm: function() {
            const form = $('#aura-judging-form');
            
            // Update total points on slider change
            form.find('.slider').on('input', function() {
                let total = 0;
                form.find('.slider').each(function() {
                    total += parseInt($(this).val());
                });
                $('#total-points').text(total);
            });

            // Handle form submission
            form.on('submit', function(e) {
                e.preventDefault();
                
                $.ajax({
                    url: auraAdmin.ajaxUrl,
                    method: 'POST',
                    data: {
                        action: 'submit_judgment',
                        nonce: auraAdmin.nonce,
                        formData: form.serialize()
                    },
                    success: function(response) {
                        if (response.success) {
                            window.location.reload();
                        }
                    }
                });
            });
        },

        initModals: function() {
            $('.view-details').on('click', function() {
                const submissionId = $(this).data('id');
                
                $.ajax({
                    url: auraAdmin.ajaxUrl,
                    data: {
                        action: 'get_submission_details',
                        nonce: auraAdmin.nonce,
                        id: submissionId
                    },
                    success: function(response) {
                        $('#submission-details-content').html(response.data);
                        $('#submission-modal').show();
                    }
                });
            });

            $('.close').on('click', function() {
                $('#submission-modal').hide();
            });
        },

        initRankings: function() {
            $('#category-filter, #season-filter').on('change', function() {
                const type = $(this).attr('id').replace('-filter', '');
                const value = $(this).val();

                $.ajax({
                    url: auraAdmin.ajaxUrl,
                    data: {
                        action: 'get_rankings',
                        nonce: auraAdmin.nonce,
                        type: type,
                        value: value
                    },
                    success: function(response) {
                        $(`#${type}-rankings-table`).html(response.data);
                    }
                });
            });
        },

        initExport: function() {
            $('#export-csv, #export-pdf').on('click', function() {
                const format = $(this).attr('id').replace('export-', '');
                
                window.location.href = auraAdmin.ajaxUrl + '?' + $.param({
                    action: 'export_rankings',
                    nonce: auraAdmin.nonce,
                    format: format
                });
            });
        }
    };

    $(document).ready(function() {
        AuraAdmin.init();
    });

})(jQuery);
