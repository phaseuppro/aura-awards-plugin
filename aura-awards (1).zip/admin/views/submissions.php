<div class="wrap aura-admin">
    <h1><?php _e('Manage Submissions', 'aura-awards'); ?></h1>

    <!-- Filters -->
    <div class="aura-filters">
        <select id="category-filter">
            <option value=""><?php _e('All Categories', 'aura-awards'); ?></option>
            <?php foreach ($this->get_categories() as $category): ?>
                <option value="<?php echo esc_attr($category); ?>">
                    <?php echo esc_html(ucfirst($category)); ?>
                </option>
            <?php endforeach; ?>
        </select>

        <select id="status-filter">
            <option value=""><?php _e('All Statuses', 'aura-awards'); ?></option>
            <option value="pending"><?php _e('Pending', 'aura-awards'); ?></option>
            <option value="approved"><?php _e('Approved', 'aura-awards'); ?></option>
            <option value="rejected"><?php _e('Rejected', 'aura-awards'); ?></option>
        </select>

        <input type="date" id="date-filter" placeholder="<?php _e('Filter by date', 'aura-awards'); ?>">
        
        <button class="button" id="apply-filters"><?php _e('Apply Filters', 'aura-awards'); ?></button>
    </div>

    <!-- Submissions Grid -->
    <div class="aura-submissions-grid">
        <?php foreach ($submissions as $submission): ?>
            <div class="submission-card" data-id="<?php echo $submission->ID; ?>">
                <div class="submission-image">
                    <?php echo get_the_post_thumbnail($submission->ID, 'medium'); ?>
                    <?php if ($badge = get_post_meta($submission->ID, 'aura_badge_level', true)): ?>
                        <div class="badge-overlay <?php echo esc_attr($badge); ?>"></div>
                    <?php endif; ?>
                </div>
                
                <div class="submission-details">
                    <h3><?php echo get_the_title($submission->ID); ?></h3>
                    <p class="photographer">
                        <?php echo get_the_author_meta('display_name', $submission->post_author); ?>
                    </p>
                    <p class="category">
                        <?php echo get_post_meta($submission->ID, 'category', true); ?>
                    </p>
                    <p class="date">
                        <?php echo get_the_date('F j, Y', $submission->ID); ?>
                    </p>
                </div>

                <div class="submission-actions">
                    <button class="button view-details" 
                            data-id="<?php echo $submission->ID; ?>">
                        <?php _e('View Details', 'aura-awards'); ?>
                    </button>
                    
                    <?php if ($submission->post_status === 'pending'): ?>
                        <button class="button button-primary start-judging" 
                                data-id="<?php echo $submission->ID; ?>">
                            <?php _e('Start Judging', 'aura-awards'); ?>
                        </button>
                    <?php endif; ?>
                </div>
            </div>
        <?php endforeach; ?>
    </div>

    <!-- Pagination -->
    <div class="aura-pagination">
        <?php echo paginate_links(array(
            'total' => $total_pages,
            'current' => $current_page,
            'format' => '?paged=%#%',
        )); ?>
    </div>
</div>

<!-- Submission Details Modal -->
<div id="submission-modal" class="aura-modal">
    <div class="modal-content">
        <span class="close">&times;</span>
        <div id="submission-details-content"></div>
    </div>
</div>
