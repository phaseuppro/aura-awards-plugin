<div class="wrap aura-admin">
    <h1><?php _e('AURA AWARDS Dashboard', 'aura-awards'); ?></h1>

    <div class="aura-dashboard-grid">
        <!-- Statistics Cards -->
        <div class="aura-stats-section">
            <div class="aura-card">
                <h3><?php _e('Total Submissions', 'aura-awards'); ?></h3>
                <div class="stat-number"><?php echo $stats['total_submissions']; ?></div>
            </div>
            <div class="aura-card">
                <h3><?php _e('Active Photographers', 'aura-awards'); ?></h3>
                <div class="stat-number"><?php echo $stats['active_photographers']; ?></div>
            </div>
            <div class="aura-card">
                <h3><?php _e('Pending Judgments', 'aura-awards'); ?></h3>
                <div class="stat-number"><?php echo $stats['pending_judgments']; ?></div>
            </div>
            <div class="aura-card">
                <h3><?php _e('Credits Sold', 'aura-awards'); ?></h3>
                <div class="stat-number"><?php echo $stats['total_credits_sold']; ?></div>
            </div>
        </div>

        <!-- Recent Activity -->
        <div class="aura-card aura-recent-activity">
            <h2><?php _e('Recent Activity', 'aura-awards'); ?></h2>
            <?php $this->display_recent_activity(); ?>
        </div>

        <!-- Top Photographers -->
        <div class="aura-card aura-top-photographers">
            <h2><?php _e('Top Photographers', 'aura-awards'); ?></h2>
            <?php $this->display_top_photographers(); ?>
        </div>

        <!-- Quick Actions -->
        <div class="aura-card aura-quick-actions">
            <h2><?php _e('Quick Actions', 'aura-awards'); ?></h2>
            <div class="action-buttons">
                <a href="<?php echo admin_url('admin.php?page=aura-submissions'); ?>" class="button button-primary">
                    <?php _e('Review Submissions', 'aura-awards'); ?>
                </a>
                <a href="<?php echo admin_url('admin.php?page=aura-judging'); ?>" class="button button-primary">
                    <?php _e('Start Judging', 'aura-awards'); ?>
                </a>
                <a href="<?php echo admin_url('admin.php?page=aura-settings'); ?>" class="button button-primary">
                    <?php _e('Manage Settings', 'aura-awards'); ?>
                </a>
            </div>
        </div>
    </div>
</div>
