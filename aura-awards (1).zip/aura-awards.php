<?php
/**
 * Plugin Name: AURA AWARDS
 * Description: Professional photography awards and ranking system
 * Version: 1.0.0
 * Author: Your Name
 * Text Domain: aura-awards
 */

if (!defined('ABSPATH')) {
    exit;
}

define('AURA_VERSION', '1.0.0');
define('AURA_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('AURA_PLUGIN_URL', plugin_dir_url(__FILE__));

require_once __DIR__ . '/vendor/autoload.php';
use Aura\Base\Container;

class Aura_Awards {
    private static $instance = null;
    private $container;

    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        $this->container = new Container();
        $this->registerServices();
        $this->init_hooks();
        $this->include_files();
    }

    private function registerServices() {
        $this->container->register([
            'config' => \Aura\Base\BaseConfig::class,
            'cache' => \Aura\Base\BaseCache::class,
            'logger' => \Aura\Base\BaseLogger::class,
            'events' => \Aura\Base\BaseEvents::class,
            'uploader' => \Aura\Base\BaseUploader::class,
            
            // Controllers
            'AwardController' => \Aura\Controllers\AwardController::class,
            'SubmissionController' => \Aura\Controllers\SubmissionController::class,
            'JudgingController' => \Aura\Controllers\JudgingController::class,
            'UserController' => \Aura\Controllers\UserController::class,
            'AdminController' => \Aura\Controllers\AdminController::class,
            
            // Services
            'AwardService' => \Aura\Services\AwardService::class,
            'SubmissionService' => \Aura\Services\SubmissionService::class,
            'JudgingService' => \Aura\Services\JudgingService::class,
            'UserService' => \Aura\Services\UserService::class,
            'AdminService' => \Aura\Services\AdminService::class,
            
            // Repositories
            'AwardRepository' => \Aura\Repositories\AwardRepository::class,
            'SubmissionRepository' => \Aura\Repositories\SubmissionRepository::class,
            'JudgingRepository' => \Aura\Repositories\JudgingRepository::class,
            'UserRepository' => \Aura\Repositories\UserRepository::class
        ]);
    }

    private function init_hooks() {
        register_activation_hook(__FILE__, array($this, 'activate'));
        register_deactivation_hook(__FILE__, array($this, 'deactivate'));
        add_action('plugins_loaded', array($this, 'load_textdomain'));
        add_action('init', array($this, 'init'));
    }

    private function include_files() {
        require_once AURA_PLUGIN_DIR . 'includes/class-member-types.php';
        require_once AURA_PLUGIN_DIR . 'includes/class-profile-fields.php';
        require_once AURA_PLUGIN_DIR . 'includes/class-activity-stream.php';
        require_once AURA_PLUGIN_DIR . 'includes/class-submission-handler.php';
        require_once AURA_PLUGIN_DIR . 'includes/class-voting-system.php';
        require_once AURA_PLUGIN_DIR . 'includes/class-badge-manager.php';
        require_once AURA_PLUGIN_DIR . 'includes/class-ranking-system.php';
        require_once AURA_PLUGIN_DIR . 'includes/class-credit-system.php';
        require_once AURA_PLUGIN_DIR . 'admin/class-admin-interface.php';
    }

    public function activate() {
        $this->create_tables();
        $this->create_roles();
        $this->runMigrations();
        flush_rewrite_rules();
    }

    public function deactivate() {
        flush_rewrite_rules();
    }

    private function create_tables() {
        global $wpdb;
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        $charset_collate = $wpdb->get_charset_collate();

        $sql = array();
        $sql[] = "CREATE TABLE IF NOT EXISTS {$wpdb->prefix}aura_rankings (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            user_id bigint(20) NOT NULL,
            points int(11) NOT NULL DEFAULT 0,
            category varchar(50),
            season varchar(20),
            type varchar(20) NOT NULL,
            rank int(11),
            PRIMARY KEY  (id),
            KEY user_id (user_id)
        ) $charset_collate;";

        $sql[] = "CREATE TABLE IF NOT EXISTS {$wpdb->prefix}aura_credit_log (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            user_id bigint(20) NOT NULL,
            credits int(11) NOT NULL,
            type varchar(20) NOT NULL,
            reference varchar(50),
            date datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY  (id),
            KEY user_id (user_id)
        ) $charset_collate;";

        foreach ($sql as $query) {
            dbDelta($query);
        }
    }

    private function runMigrations() {
        $migrations = [
            new \Aura\Database\Migrations\CreateAwardsTable(),
            new \Aura\Database\Migrations\CreateSubmissionsTable(),
            new \Aura\Database\Migrations\CreateJudgingTable(),
            new \Aura\Database\Migrations\CreateUserAwardsTable()
        ];

        foreach ($migrations as $migration) {
            $migration->up();
        }
    }

    private function create_roles() {
        add_role('photographer', 'Photographer', array(
            'read' => true,
            'upload_files' => true,
            'edit_posts' => false
        ));
    }

    public function load_textdomain() {
        load_plugin_textdomain('aura-awards', false, dirname(plugin_basename(__FILE__)) . '/languages/');
    }

    public function init() {
        if (!class_exists('BuddyPress')) {
            add_action('admin_notices', array($this, 'buddypress_notice'));
            return;
        }
    }

    public function buddypress_notice() {
        echo '<div class="error"><p>';
        _e('AURA AWARDS requires BuddyPress to be installed and active.', 'aura-awards');
        echo '</p></div>';
    }
}

// Initialize the plugin
function aura_awards() {
    return Aura_Awards::get_instance();
}

aura_awards();
