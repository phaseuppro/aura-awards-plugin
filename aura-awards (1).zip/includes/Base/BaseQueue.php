<?php

namespace Aura\Base;

class BaseQueue {
    protected $container;
    protected $table;
    protected $config;

    public function __construct($container) {
        $this->container = $container;
        $this->config = $container->get('config')->get('queue');
        $this->table = $this->config['table'];
    }

    public function push($job, $data = [], $queue = 'default') {
        global $wpdb;

        return $wpdb->insert($this->table, [
            'queue' => $queue,
            'payload' => serialize([
                'job' => $job,
                'data' => $data
            ]),
            'attempts' => 0,
            'created_at' => current_time('mysql'),
            'available_at' => current_time('mysql')
        ]);
    }

    public function later($delay, $job, $data = [], $queue = 'default') {
        global $wpdb;

        return $wpdb->insert($this->table, [
            'queue' => $queue,
            'payload' => serialize([
                'job' => $job,
                'data' => $data
            ]),
            'attempts' => 0,
            'created_at' => current_time('mysql'),
            'available_at' => date('Y-m-d H:i:s', strtotime("+{$delay} seconds"))
        ]);
    }

    public function pop($queue = 'default') {
        global $wpdb;

        $job = $wpdb->get_row($wpdb->prepare("
            SELECT * FROM {$this->table}
            WHERE queue = %s
            AND available_at <= %s
            ORDER BY created_at ASC
            LIMIT 1
        ", $queue, current_time('mysql')));

        if ($job) {
            $wpdb->delete($this->table, ['id' => $job->id]);
            return unserialize($job->payload);
        }

        return null;
    }
}
