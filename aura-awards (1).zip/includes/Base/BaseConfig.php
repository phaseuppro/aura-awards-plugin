<?php

namespace Aura\Base;

class BaseConfig {
    protected $config = [];
    protected $loaded = false;

    public function __construct() {
        $this->loadConfig();
    }

    public function get($key = null, $default = null) {
        if ($key === null) {
            return $this->config;
        }

        $keys = explode('.', $key);
        $value = $this->config;

        foreach ($keys as $segment) {
            if (!isset($value[$segment])) {
                return $default;
            }
            $value = $value[$segment];
        }

        return $value;
    }

    public function set($key, $value) {
        $keys = explode('.', $key);
        $config = &$this->config;

        foreach ($keys as $segment) {
            if (!isset($config[$segment])) {
                $config[$segment] = [];
            }
            $config = &$config[$segment];
        }

        $config = $value;
        return $this;
    }

    protected function loadConfig() {
        if ($this->loaded) {
            return;
        }

        $configPath = plugin_dir_path(dirname(__FILE__)) . 'config/';
        $files = glob($configPath . '*.php');

        foreach ($files as $file) {
            $key = basename($file, '.php');
            $this->config[$key] = require $file;
        }

        $this->loaded = true;
    }
}
