<?php

namespace Aura\Base;

class BaseRequest {
    protected $params;
    protected $method;
    protected $headers;
    protected $files;

    public function __construct() {
        $this->method = $_SERVER['REQUEST_METHOD'];
        $this->headers = $this->getHeaders();
        $this->params = $this->getParams();
        $this->files = $_FILES;
    }

    public function get($key = null, $default = null) {
        if ($key === null) {
            return $this->params;
        }
        return $this->params[$key] ?? $default;
    }

    public function header($key = null, $default = null) {
        if ($key === null) {
            return $this->headers;
        }
        return $this->headers[$key] ?? $default;
    }

    public function file($key = null) {
        if ($key === null) {
            return $this->files;
        }
        return $this->files[$key] ?? null;
    }

    public function method() {
        return $this->method;
    }

    public function isMethod($method) {
        return strtoupper($method) === $this->method;
    }

    public function isAjax() {
        return isset($this->headers['X-Requested-With']) && 
               $this->headers['X-Requested-With'] === 'XMLHttpRequest';
    }

    protected function getHeaders() {
        $headers = [];
        foreach ($_SERVER as $key => $value) {
            if (strpos($key, 'HTTP_') === 0) {
                $header = str_replace(' ', '-', ucwords(str_replace('_', ' ', strtolower(substr($key, 5)))));
                $headers[$header] = $value;
            }
        }
        return $headers;
    }

    protected function getParams() {
        $params = [];
        
        switch ($this->method) {
            case 'GET':
                $params = $_GET;
                break;
            case 'POST':
                $params = $_POST;
                break;
            default:
                $input = file_get_contents('php://input');
                if (!empty($input)) {
                    $params = json_decode($input, true) ?? [];
                }
        }

        return array_merge($_GET, $params);
    }
}
