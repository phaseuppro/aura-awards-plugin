<?php

namespace Aura\Base;

class BaseService {
    protected $repository;
    protected $validator;
    protected $events;
    protected $logger;

    public function __construct($container) {
        $this->validator = $container->get('validator');
        $this->events = $container->get('events');
        $this->logger = $container->get('logger');
    }

    protected function validate($data, $rules) {
        $validation = $this->validator->make($data, $rules);

        if ($validation->fails()) {
            throw new \Exception(json_encode($validation->errors()));
        }

        return $validation->validated();
    }

    protected function dispatchEvent($event, $payload = []) {
        $this->events->dispatch($event, $payload);
        $this->logger->info("Event dispatched: {$event}", $payload);
    }

    protected function beginTransaction() {
        global $wpdb;
        $wpdb->query('START TRANSACTION');
    }

    protected function commitTransaction() {
        global $wpdb;
        $wpdb->query('COMMIT');
    }

    protected function rollbackTransaction() {
        global $wpdb;
        $wpdb->query('ROLLBACK');
    }

    protected function withTransaction(callable $callback) {
        try {
            $this->beginTransaction();
            $result = $callback();
            $this->commitTransaction();
            return $result;
        } catch (\Exception $e) {
            $this->rollbackTransaction();
            throw $e;
        }
    }
}
