<?php

namespace Aura\Base;

class BaseException extends \Exception {
    protected $errors = [];
    protected $context = [];
    protected $httpCode = 500;

    public function __construct($message = "", $code = 0, $errors = [], $context = [], $httpCode = 500) {
        parent::__construct($message, $code);
        
        $this->errors = $errors;
        $this->context = $context;
        $this->httpCode = $httpCode;
    }

    public function getErrors() {
        return $this->errors;
    }

    public function getContext() {
        return $this->context;
    }

    public function getHttpCode() {
        return $this->httpCode;
    }

    public function toArray() {
        return [
            'message' => $this->getMessage(),
            'code' => $this->getCode(),
            'errors' => $this->getErrors(),
            'context' => $this->getContext(),
            'file' => $this->getFile(),
            'line' => $this->getLine(),
            'trace' => $this->getTraceAsString()
        ];
    }

    public function toJson() {
        return json_encode($this->toArray());
    }
}
