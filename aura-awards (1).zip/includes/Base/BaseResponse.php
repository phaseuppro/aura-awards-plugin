<?php

namespace Aura\Base;

class BaseResponse {
    protected $data;
    protected $status;
    protected $headers = [];

    public function __construct($data = null, $status = 200) {
        $this->data = $data;
        $this->status = $status;
    }

    public function send() {
        $this->sendHeaders();
        
        if (is_array($this->data) || is_object($this->data)) {
            return wp_send_json($this->data, $this->status);
        }
        
        echo $this->data;
        return true;
    }

    public function json($data, $status = 200) {
        $this->data = $data;
        $this->status = $status;
        $this->header('Content-Type', 'application/json');
        return $this;
    }

    public function header($key, $value) {
        $this->headers[$key] = $value;
        return $this;
    }

    public function status($code) {
        $this->status = $code;
        return $this;
    }

    public function redirect($url, $status = 302) {
        wp_redirect($url, $status);
        exit;
    }

    protected function sendHeaders() {
        if (!headers_sent()) {
            http_response_code($this->status);
            
            foreach ($this->headers as $key => $value) {
                header("$key: $value");
            }
        }
    }
}
