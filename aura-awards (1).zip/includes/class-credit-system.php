<?php
if (!defined('ABSPATH')) {
    exit;
}

class Aura_Credit_System {
    private static $instance = null;
    private $credit_packages = array(
        'single' => array(
            'credits' => 1,
            'price' => 10,
            'name' => 'Single Submission'
        ),
        'triple' => array(
            'credits' => 3,
            'price' => 25,
            'name' => 'Triple Package'
        ),
        'pro' => array(
            'credits' => 10,
            'price' => 75,
            'name' => 'Pro Package'
        ),
        'unlimited' => array(
            'credits' => 50,
            'price' => 299,
            'name' => 'Unlimited Package'
        )
    );

    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        $this->init_hooks();
    }

    private function init_hooks() {
        add_action('init', array($this, 'register_credit_products'));
        add_action('woocommerce_order_status_completed', array($this, 'process_credit_purchase'));
        add_action('woocommerce_before_calculate_totals', array($this, 'apply_credit_package_pricing'));
        add_filter('woocommerce_add_to_cart_validation', array($this, 'validate_credit_purchase'), 10, 3);
    }

    public function register_credit_products() {
        foreach ($this->credit_packages as $id => $package) {
            $this->create_credit_product($id, $package);
        }
    }

    private function create_credit_product($id, $package) {
        $product = new WC_Product_Simple();
        $product->set_name($package['name']);
        $product->set_regular_price($package['price']);
        $product->set_description(sprintf(
            'Purchase %d submission credits for AURA AWARDS',
            $package['credits']
        ));
        $product->set_virtual(true);
        $product->set_sold_individually(true);
        $product->save();

        update_post_meta($product->get_id(), '_aura_credits', $package['credits']);
        update_post_meta($product->get_id(), '_aura_credit_package', $id);
    }

    public function process_credit_purchase($order_id) {
        $order = wc_get_order($order_id);
        $user_id = $order->get_user_id();

        foreach ($order->get_items() as $item) {
            $product_id = $item->get_product_id();
            $credits = get_post_meta($product_id, '_aura_credits', true);
            $this->add_credits($user_id, $credits);

            // Log transaction
            $this->log_credit_transaction($user_id, $credits, 'purchase', $order_id);
        }
    }

    private function add_credits($user_id, $credits) {
        $current_credits = get_user_meta($user_id, 'aura_credits', true);
        $new_total = intval($current_credits) + intval($credits);
        update_user_meta($user_id, 'aura_credits', $new_total);
    }

    public function deduct_credits($user_id, $amount = 1) {
        $current_credits = get_user_meta($user_id, 'aura_credits', true);
        
        if ($current_credits >= $amount) {
            update_user_meta($user_id, 'aura_credits', $current_credits - $amount);
            $this->log_credit_transaction($user_id, $amount, 'deduction');
            return true;
        }
        
        return false;
    }

    private function log_credit_transaction($user_id, $credits, $type, $reference = '') {
        global $wpdb;
        $table = $wpdb->prefix . 'aura_credit_log';

        $wpdb->insert($table, array(
            'user_id' => $user_id,
            'credits' => $credits,
            'type' => $type,
            'reference' => $reference,
            'date' => current_time('mysql')
        ));
    }

    public function get_user_credits($user_id = null) {
        if (!$user_id) {
            $user_id = get_current_user_id();
        }
        return get_user_meta($user_id, 'aura_credits', true);
    }

    public function get_credit_packages() {
        return $this->credit_packages;
    }
}

// Initialize the class
function aura_credit_system() {
    return Aura_Credit_System::get_instance();
}
aura_credit_system();
