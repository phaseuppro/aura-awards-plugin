<?php
namespace Aura\Repositories;
use Aura\Base\BaseRepository;
use Aura\Models\Judging;

class JudgingRepository extends BaseRepository {
    protected $model = Judging::class;

    public function getPendingSubmissions() {
        global $wpdb;
        return $wpdb->get_results("
            SELECT s.* FROM {$this->table} j
            RIGHT JOIN aura_submissions s ON s.id = j.submission_id
            WHERE j.id IS NULL AND s.status = 'approved'
        ");
    }

    public function getJudgingHistory($judgeId) {
        return $this->all(['where' => "judge_id = {$judgeId}"]);
    }
}
