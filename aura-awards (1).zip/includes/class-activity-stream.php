<?php
if (!defined('ABSPATH')) {
    exit;
}

class Aura_Activity_Stream {
    private static $instance = null;
    private $activity_types = array(
        'photo_submission' => 'New Photo Submission',
        'badge_earned' => 'Badge Earned',
        'ranking_update' => 'Ranking Updated',
        'contest_win' => 'Contest Win'
    );

    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        $this->init_hooks();
    }

    private function init_hooks() {
        add_action('bp_register_activity_actions', array($this, 'register_activity_types'));
        add_action('aura_photo_submitted', array($this, 'log_photo_submission'));
        add_action('aura_badge_earned', array($this, 'log_badge_earned'));
        add_action('aura_ranking_updated', array($this, 'log_ranking_update'));
        add_filter('bp_get_activity_action_pre_meta', array($this, 'format_activity_action'));
    }

    public function register_activity_types() {
        foreach ($this->activity_types as $type => $label) {
            bp_activity_set_action(
                buddypress()->activity->id,
                $type,
                $label,
                array(
                    'activity' => true,
                    'notification' => true
                )
            );
        }
    }

    public function log_photo_submission($submission_data) {
        bp_activity_add(array(
            'user_id' => get_current_user_id(),
            'action' => sprintf(
                __('%s submitted a new photo in %s category', 'aura-awards'),
                bp_core_get_userlink(get_current_user_id()),
                $submission_data['category']
            ),
            'component' => buddypress()->activity->id,
            'type' => 'photo_submission',
            'item_id' => $submission_data['submission_id']
        ));
    }

    public function log_badge_earned($badge_data) {
        bp_activity_add(array(
            'user_id' => $badge_data['user_id'],
            'action' => sprintf(
                __('%s earned a %s badge!', 'aura-awards'),
                bp_core_get_userlink($badge_data['user_id']),
                $badge_data['badge_level']
            ),
            'component' => buddypress()->activity->id,
            'type' => 'badge_earned',
            'item_id' => $badge_data['submission_id']
        ));
    }

    public function log_ranking_update($ranking_data) {
        bp_activity_add(array(
            'user_id' => $ranking_data['user_id'],
            'action' => sprintf(
                __('%s moved to rank #%d in %s category!', 'aura-awards'),
                bp_core_get_userlink($ranking_data['user_id']),
                $ranking_data['new_rank'],
                $ranking_data['category']
            ),
            'component' => buddypress()->activity->id,
            'type' => 'ranking_update'
        ));
    }

    public function format_activity_action($action) {
        // Add custom formatting for activity items
        return $action;
    }

    public function get_user_activity($user_id, $type = '') {
        $args = array(
            'user_id' => $user_id,
            'display_comments' => 'stream'
        );

        if (!empty($type)) {
            $args['type'] = $type;
        }

        return bp_activity_get($args);
    }
}

// Initialize the class
function aura_activity_stream() {
    return Aura_Activity_Stream::get_instance();
}
aura_activity_stream();
