<?php
namespace Aura\Services;
use Aura\Base\BaseService;

class AdminService extends BaseService {
    protected $submissionRepo;
    protected $userRepo;

    public function __construct($container) {
        parent::__construct($container);
        $this->submissionRepo = $container->get('SubmissionRepository');
        $this->userRepo = $container->get('UserRepository');
    }

    public function getDashboardStats() {
        return [
            'total_submissions' => $this->submissionRepo->count(),
            'pending_reviews' => $this->submissionRepo->countPending(),
            'awarded_submissions' => $this->submissionRepo->countAwarded(),
            'active_judges' => $this->userRepo->countJudges()
        ];
    }

    public function getAllSubmissions() {
        return $this->submissionRepo->getAllWithDetails();
    }

    public function getAllJudges() {
        return $this->userRepo->getAllJudges();
    }

    public function assignJudgeToSubmission($submissionId, $judgeId) {
        $this->validate([
            'submission_id' => $submissionId,
            'judge_id' => $judgeId
        ], [
            'submission_id' => 'required|numeric',
            'judge_id' => 'required|numeric'
        ]);

        return $this->submissionRepo->assignJudge($submissionId, $judgeId);
    }

    public function getSettings() {
        return get_option('aura_awards_settings', []);
    }

    public function updateSettings($settings) {
        update_option('aura_awards_settings', $settings);
        return $settings;
    }
}
