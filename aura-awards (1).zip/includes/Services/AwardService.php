<?php
namespace Aura\Services;
use Aura\Base\BaseService;

class AwardService extends BaseService {
    protected $awardRepo;

    public function __construct($container) {
        parent::__construct($container);
        $this->awardRepo = $container->get('AwardRepository');
    }

    public function getAllAwards() {
        return $this->awardRepo->all();
    }

    public function createAward($data) {
        $this->validate($data, [
            'title' => 'required|string',
            'points' => 'required|numeric'
        ]);
        
        $award = $this->awardRepo->create($data);
        $this->dispatchEvent('award.created', $award);
        return $award;
    }

    public function updateAward($id, $data) {
        return $this->awardRepo->update($id, $data);
    }

    public function deleteAward($id) {
        return $this->awardRepo->delete($id);
    }
}
