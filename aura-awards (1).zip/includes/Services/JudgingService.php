<?php
namespace Aura\Services;
use Aura\Base\BaseService;

class JudgingService extends BaseService {
    protected $judgingRepo;

    public function __construct($container) {
        parent::__construct($container);
        $this->judgingRepo = $container->get('JudgingRepository');
    }

    public function getPendingSubmissions() {
        return $this->judgingRepo->getPendingSubmissions();
    }

    public function submitScore($submissionId, $data) {
        $this->validate($data, [
            'technical_score' => 'required|numeric|min:0|max:100',
            'artistic_score' => 'required|numeric|min:0|max:100',
            'feedback' => 'required|string|min:10'
        ]);

        $data['judge_id'] = get_current_user_id();
        $data['submission_id'] = $submissionId;
        $data['status'] = 'completed';

        $judging = $this->judgingRepo->create($data);
        $this->dispatchEvent('judging.score_submitted', $judging);
        return $judging;
    }

    public function getJudgingHistory() {
        return $this->judgingRepo->getJudgingHistory(get_current_user_id());
    }
}
