<?php
namespace Aura\Services;
use Aura\Base\BaseService;

class SubmissionService extends BaseService {
    protected $submissionRepo;
    protected $uploader;

    public function __construct($container) {
        parent::__construct($container);
        $this->submissionRepo = $container->get('SubmissionRepository');
        $this->uploader = $container->get('uploader');
    }

    public function getAllSubmissions() {
        return $this->submissionRepo->all();
    }

    public function createSubmission($data, $file) {
        $this->validate($data, [
            'title' => 'required|string',
            'category_id' => 'required|numeric'
        ]);

        if ($file) {
            $upload = $this->uploader->upload($file, 'submissions');
            $data['image_url'] = $upload['url'];
        }

        $data['user_id'] = get_current_user_id();
        $data['status'] = 'pending';
        
        $submission = $this->submissionRepo->create($data);
        $this->dispatchEvent('submission.created', $submission);
        return $submission;
    }

    public function updateSubmission($id, $data) {
        return $this->submissionRepo->update($id, $data);
    }

    public function deleteSubmission($id) {
        return $this->submissionRepo->delete($id);
    }
}
