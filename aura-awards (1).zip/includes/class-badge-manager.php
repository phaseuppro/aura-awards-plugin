<?php
if (!defined('ABSPATH')) {
    exit;
}

class Aura_Badge_Manager {
    private static $instance = null;
    private $badge_sizes = array(
        'width' => 350,
        'height' => 350
    );

    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        $this->init_hooks();
    }

    private function init_hooks() {
        add_action('aura_vote_completed', array($this, 'process_badge'));
        add_action('wp_ajax_update_badge_position', array($this, 'update_badge_position'));
        add_action('admin_enqueue_scripts', array($this, 'enqueue_badge_assets'));
    }

    public function process_badge($vote_data) {
        $submission_id = $vote_data['submission_id'];
        $badge_level = $vote_data['badge_level'];
        
        // Get original image
        $image_id = get_post_thumbnail_id($submission_id);
        $image_path = get_attached_file($image_id);
        
        // Apply badge
        $this->apply_badge($image_path, $badge_level);
        
        // Update metadata
        $this->update_badge_metadata($submission_id, $badge_level);
    }

    private function apply_badge($image_path, $badge_level) {
        // Load images
        $image = imagecreatefromjpeg($image_path);
        $badge = imagecreatefrompng($this->get_badge_path($badge_level));
        
        // Calculate position (default: bottom-right)
        $position = $this->calculate_badge_position($image);
        
        // Apply badge with transparency
        imagecopy(
            $image,
            $badge,
            $position['x'],
            $position['y'],
            0,
            0,
            $this->badge_sizes['width'],
            $this->badge_sizes['height']
        );
        
        // Save image
        imagejpeg($image, $image_path, 100);
        
        // Clean up
        imagedestroy($image);
        imagedestroy($badge);
    }

    private function get_badge_path($level) {
        return AURA_PLUGIN_DIR . 'assets/badges/' . $level . '.png';
    }

    private function calculate_badge_position($image, $position = 'bottom-right') {
        $width = imagesx($image);
        $height = imagesy($image);
        
        $positions = array(
            'top-left' => array('x' => 0, 'y' => 0),
            'top-right' => array('x' => $width - $this->badge_sizes['width'], 'y' => 0),
            'bottom-left' => array('x' => 0, 'y' => $height - $this->badge_sizes['height']),
            'bottom-right' => array('x' => $width - $this->badge_sizes['width'], 'y' => $height - $this->badge_sizes['height'])
        );
        
        return $positions[$position];
    }

    private function update_badge_metadata($submission_id, $badge_level) {
        update_post_meta($submission_id, 'aura_badge_applied', true);
        update_post_meta($submission_id, 'aura_badge_position', 'bottom-right');
        
        // Update user badge count
        $user_id = get_post_field('post_author', $submission_id);
        $badges = get_user_meta($user_id, 'aura_badges', true);
        $badges = !empty($badges) ? $badges : array();
        $badges[$badge_level] = isset($badges[$badge_level]) ? $badges[$badge_level] + 1 : 1;
        update_user_meta($user_id, 'aura_badges', $badges);
    }

    public function update_badge_position() {
        check_ajax_referer('aura_badge_position', 'nonce');
        
        $submission_id = intval($_POST['submission_id']);
        $position = sanitize_text_field($_POST['position']);
        
        // Reapply badge with new position
        $image_id = get_post_thumbnail_id($submission_id);
        $image_path = get_attached_file($image_id);
        $badge_level = get_post_meta($submission_id, 'aura_badge_level', true);
        
        $this->apply_badge($image_path, $badge_level, $position);
        update_post_meta($submission_id, 'aura_badge_position', $position);
        
        wp_send_json_success(__('Badge position updated', 'aura-awards'));
    }
}

// Initialize the class
function aura_badge_manager() {
    return Aura_Badge_Manager::get_instance();
}
aura_badge_manager();


