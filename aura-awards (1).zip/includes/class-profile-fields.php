<?php
if (!defined('ABSPATH')) {
    exit;
}

class Aura_Profile_Fields {
    private static $instance = null;
    private $field_groups = array();

    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        $this->setup_field_groups();
        $this->init_hooks();
    }

    private function setup_field_groups() {
        $this->field_groups = array(
            'professional_info' => array(
                'name' => 'Professional Information',
                'description' => 'Your photography expertise and background',
                'fields' => array(
                    array(
                        'name' => 'Experience Level',
                        'type' => 'selectbox',
                        'options' => array('1-3 years', '4-7 years', '8+ years'),
                        'required' => true
                    ),
                    array(
                        'name' => 'Specializations',
                        'type' => 'checkbox',
                        'options' => array('Maternity', 'Newborn', 'Children', 'Family', 'AI-Infused'),
                        'required' => true
                    ),
                    array(
                        'name' => 'Website',
                        'type' => 'url',
                        'required' => false
                    ),
                    array(
                        'name' => 'Professional Bio',
                        'type' => 'textarea',
                        'required' => true
                    )
                )
            ),
            'achievements' => array(
                'name' => 'Achievements',
                'description' => 'Your AURA AWARDS achievements',
                'fields' => array(
                    array(
                        'name' => 'Total Points',
                        'type' => 'number',
                        'readonly' => true
                    ),
                    array(
                        'name' => 'Badges Earned',
                        'type' => 'number',
                        'readonly' => true
                    ),
                    array(
                        'name' => 'Current Ranking',
                        'type' => 'text',
                        'readonly' => true
                    )
                )
            )
        );
    }

    private function init_hooks() {
        add_action('bp_setup_profile_fields', array($this, 'create_profile_fields'));
        add_action('bp_after_profile_field_content', array($this, 'display_achievements'));
        add_filter('bp_get_the_profile_field_value', array($this, 'format_field_value'), 10, 3);
    }

    public function create_profile_fields() {
        foreach ($this->field_groups as $group_id => $group) {
            $group_id = xprofile_insert_field_group(array(
                'name' => $group['name'],
                'description' => $group['description']
            ));

            foreach ($group['fields'] as $field) {
                xprofile_insert_field(array(
                    'field_group_id' => $group_id,
                    'name' => $field['name'],
                    'type' => $field['type'],
                    'is_required' => !empty($field['required']),
                    'can_delete' => false,
                    'field_order' => 1,
                    'option_order' => 1,
                    'order_by' => 'custom',
                    'is_default_option' => 0
                ));
            }
        }
    }

    public function display_achievements() {
        if (bp_is_profile_achievements_section()) {
            $user_id = bp_displayed_user_id();
            $achievements = $this->get_user_achievements($user_id);
            include AURA_PLUGIN_DIR . 'templates/achievements-display.php';
        }
    }

    private function get_user_achievements($user_id) {
        return array(
            'total_points' => get_user_meta($user_id, 'aura_total_points', true),
            'badges' => get_user_meta($user_id, 'aura_badges', true),
            'ranking' => get_user_meta($user_id, 'aura_ranking', true)
        );
    }
}

// Initialize the class
function aura_profile_fields() {
    return Aura_Profile_Fields::get_instance();
}
aura_profile_fields();
