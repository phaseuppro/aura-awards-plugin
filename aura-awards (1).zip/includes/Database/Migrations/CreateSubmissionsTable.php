<?php
namespace Aura\Database\Migrations;
use Aura\Base\BaseMigration;

class CreateSubmissionsTable extends BaseMigration {
    public function up() {
        $this->createTable($this->wpdb->prefix . 'aura_submissions', "
            title varchar(255) NOT NULL,
            description text,
            user_id bigint(20) unsigned NOT NULL,
            category_id bigint(20) unsigned NOT NULL,
            image_url varchar(255),
            status varchar(20) DEFAULT 'pending',
            score decimal(5,2) DEFAULT 0.00
        ");
    }

    public function down() {
        $this->dropTable($this->wpdb->prefix . 'aura_submissions');
    }
}
