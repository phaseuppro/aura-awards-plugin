<?php
namespace Aura\Database\Migrations;
use Aura\Base\BaseMigration;

class CreateAwardsTable extends BaseMigration {
    public function up() {
        $this->createTable($this->wpdb->prefix . 'aura_awards', "
            title varchar(255) NOT NULL,
            description text,
            category_id bigint(20) unsigned,
            points int(11) DEFAULT 0,
            badge_url varchar(255),
            status varchar(20) DEFAULT 'active'
        ");
    }

    public function down() {
        $this->dropTable($this->wpdb->prefix . 'aura_awards');
    }
}
