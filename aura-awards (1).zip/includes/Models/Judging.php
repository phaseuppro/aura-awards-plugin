<?php
namespace Aura\Models;
use Aura\Base\BaseModel;

class Judging extends BaseModel {
    protected $table = 'aura_judging';
    protected $fillable = ['submission_id', 'judge_id', 'technical_score', 'artistic_score', 'feedback', 'status'];
}
