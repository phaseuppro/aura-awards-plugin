<?php

return [
    'email' => [
        'submission_received' => [
            'subject' => 'Your submission has been received',
            'template' => 'emails/submission-received',
            'recipients' => ['photographer', 'admin']
        ],
        'submission_approved' => [
            'subject' => 'Your submission has been approved',
            'template' => 'emails/submission-approved',
            'recipients' => ['photographer']
        ],
        'judging_complete' => [
            'subject' => 'Your submission has been judged',
            'template' => 'emails/judging-complete',
            'recipients' => ['photographer']
        ],
        'award_granted' => [
            'subject' => 'Congratulations! You\'ve won an award',
            'template' => 'emails/award-granted',
            'recipients' => ['photographer']
        ],
        'new_judge_assigned' => [
            'subject' => 'New submissions ready for judging',
            'template' => 'emails/judge-assigned',
            'recipients' => ['judge']
        ]
    ],

    'admin' => [
        'new_submission' => [
            'message' => 'New submission received from {photographer}',
            'type' => 'info',
            'action' => 'View Submission'
        ],
        'judging_needed' => [
            'message' => 'Submission requires additional judges',
            'type' => 'warning',
            'action' => 'Assign Judges'
        ],
        'award_pending' => [
            'message' => 'Award certificate ready for approval',
            'type' => 'success',
            'action' => 'Review Award'
        ]
    ],

    'user' => [
        'submission_status' => [
            'pending' => 'Your submission is being reviewed',
            'approved' => 'Your submission has been approved',
            'judging' => 'Your submission is being judged',
            'awarded' => 'Congratulations! Your submission has won an award'
        ],
        'account_status' => [
            'verified' => 'Your account has been verified',
            'upgraded' => 'Your account has been upgraded to {role}',
            'suspended' => 'Your account has been temporarily suspended'
        ]
    ]
];
