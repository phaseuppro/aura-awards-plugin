<?php

return [
    'submission' => [
        'title' => [
            'required' => true,
            'type' => 'string',
            'min' => 3,
            'max' => 100
        ],
        'description' => [
            'required' => true,
            'type' => 'string',
            'min' => 10,
            'max' => 1000
        ],
        'category_id' => [
            'required' => true,
            'type' => 'integer',
            'exists' => 'categories,id'
        ],
        'image' => [
            'required' => true,
            'type' => 'file',
            'mimes' => ['jpg', 'jpeg', 'png'],
            'max_size' => 10240, // 10MB
            'dimensions' => [
                'min_width' => 1920,
                'min_height' => 1080,
                'max_width' => 5000,
                'max_height' => 5000
            ]
        ]
    ],

    'judging' => [
        'technical_score' => [
            'required' => true,
            'type' => 'integer',
            'min' => 0,
            'max' => 100
        ],
        'artistic_score' => [
            'required' => true,
            'type' => 'integer',
            'min' => 0,
            'max' => 100
        ],
        'feedback' => [
            'required' => true,
            'type' => 'string',
            'min' => 20,
            'max' => 500
        ]
    ],

    'user' => [
        'display_name' => [
            'required' => true,
            'type' => 'string',
            'min' => 2,
            'max' => 50
        ],
        'email' => [
            'required' => true,
            'type' => 'email',
            'unique' => 'users,email'
        ],
        'biography' => [
            'required' => false,
            'type' => 'string',
            'max' => 1000
        ],
        'website' => [
            'required' => false,
            'type' => 'url'
        ]
    ]
];
