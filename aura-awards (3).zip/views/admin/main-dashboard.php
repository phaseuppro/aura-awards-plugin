<?php
if (!defined('ABSPATH')) exit;
?>

<div class="wrap aura-awards-admin">
    <h1><?php echo esc_html(get_admin_page_title()); ?></h1>
    
    <div class="aura-admin-tabs">
        <nav class="nav-tab-wrapper">
            <a href="?page=aura-awards&tab=dashboard" class="nav-tab <?php echo $active_tab === 'dashboard' ? 'nav-tab-active' : ''; ?>">
                Dashboard
            </a>
            <a href="?page=aura-awards&tab=submissions" class="nav-tab <?php echo $active_tab === 'submissions' ? 'nav-tab-active' : ''; ?>">
                Submissions
            </a>
            <a href="?page=aura-awards&tab=judging" class="nav-tab <?php echo $active_tab === 'judging' ? 'nav-tab-active' : ''; ?>">
                Judging
            </a>
            <a href="?page=aura-awards&tab=settings" class="nav-tab <?php echo $active_tab === 'settings' ? 'nav-tab-active' : ''; ?>">
                Settings
            </a>
        </nav>

        <div class="tab-content">
            <?php
            switch($active_tab) {
                case 'dashboard':
                    include AURA_PLUGIN_DIR . 'views/admin/dashboard-tab.php';
                    break;
                case 'submissions':
                    include AURA_PLUGIN_DIR . 'views/admin/submissions-tab.php';
                    break;
                case 'judging':
                    include AURA_PLUGIN_DIR . 'views/admin/judging-tab.php';
                    break;
                case 'settings':
                    include AURA_PLUGIN_DIR . 'views/admin/settings-tab.php';
                    break;
            }
            ?>
        </div>
    </div>
</div>
