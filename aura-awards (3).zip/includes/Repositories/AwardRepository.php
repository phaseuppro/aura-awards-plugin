<?php
namespace Aura\Repositories;
use Aura\Base\BaseRepository;
use Aura\Models\Award;

class AwardRepository extends BaseRepository {
    protected $model = Award::class;
}
