<?php
namespace Aura\Repositories;
use Aura\Base\BaseRepository;
use Aura\Models\Submission;

class SubmissionRepository extends BaseRepository {
    protected $model = Submission::class;
}
