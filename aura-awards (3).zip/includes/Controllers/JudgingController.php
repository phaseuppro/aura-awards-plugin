<?php
namespace Aura\Controllers;
use Aura\Base\BaseController;

class JudgingController extends BaseController {
    protected $judgingService;

    public function __construct($container) {
        parent::__construct($container);
        $this->judgingService = $container->get('JudgingService');
    }

    public function getPendingSubmissions() {
        return $this->json($this->judgingService->getPendingSubmissions());
    }

    public function submitScore($submissionId) {
        return $this->json(
            $this->judgingService->submitScore($submissionId, $this->request->get()),
            201
        );
    }

    public function getJudgingHistory() {
        return $this->json($this->judgingService->getJudgingHistory());
    }
}
