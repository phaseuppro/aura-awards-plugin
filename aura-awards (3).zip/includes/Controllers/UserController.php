<?php
namespace Aura\Controllers;
use Aura\Base\BaseController;

class UserController extends BaseController {
    protected $userService;

    public function __construct($container) {
        parent::__construct($container);
        $this->userService = $container->get('UserService');
    }

    public function profile() {
        return $this->json($this->userService->getCurrentUserProfile());
    }

    public function updateProfile() {
        return $this->json($this->userService->updateProfile($this->request->get()));
    }

    public function submissions() {
        return $this->json($this->userService->getUserSubmissions());
    }

    public function awards() {
        return $this->json($this->userService->getUserAwards());
    }
}
