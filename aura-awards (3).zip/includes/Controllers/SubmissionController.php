<?php
namespace Aura\Controllers;
use Aura\Base\BaseController;

class SubmissionController extends BaseController {
    protected $submissionService;

    public function __construct($container) {
        parent::__construct($container);
        $this->submissionService = $container->get('SubmissionService');
    }

    public function index() {
        return $this->json($this->submissionService->getAllSubmissions());
    }

    public function store() {
        $data = $this->request->get();
        $files = $this->request->file('image');
        return $this->json(
            $this->submissionService->createSubmission($data, $files),
            201
        );
    }

    public function update($id) {
        return $this->json($this->submissionService->updateSubmission($id, $this->request->get()));
    }

    public function delete($id) {
        $this->submissionService->deleteSubmission($id);
        return $this->json(null, 204);
    }
}
