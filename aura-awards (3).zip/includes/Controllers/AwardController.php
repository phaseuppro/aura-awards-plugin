<?php
namespace Aura\Controllers;
use Aura\Base\BaseController;

class AwardController extends BaseController {
    protected $awardService;

    public function __construct($container) {
        parent::__construct($container);
        $this->awardService = $container->get('AwardService');
    }

    public function index() {
        return $this->json($this->awardService->getAllAwards());
    }

    public function store() {
        return $this->json(
            $this->awardService->createAward($this->request->get()),
            201
        );
    }

    public function update($id) {
        return $this->json($this->awardService->updateAward($id, $this->request->get()));
    }

    public function delete($id) {
        $this->awardService->deleteAward($id);
        return $this->json(null, 204);
    }
}
