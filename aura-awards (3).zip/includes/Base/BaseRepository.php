<?php

namespace Aura\Base;

class BaseRepository {
    protected $model;
    protected $cache;
    protected $table;

    public function __construct($container) {
        $this->cache = $container->get('cache');
        $this->table = $this->model::getTable();
    }

    public function find($id) {
        global $wpdb;
        
        $cacheKey = "aura_{$this->table}_{$id}";
        
        if ($cached = $this->cache->get($cacheKey)) {
            return new $this->model($cached);
        }

        $result = $wpdb->get_row(
            $wpdb->prepare(
                "SELECT * FROM {$this->table} WHERE id = %d",
                $id
            ),
            ARRAY_A
        );

        if ($result) {
            $this->cache->set($cacheKey, $result);
            return new $this->model($result);
        }

        return null;
    }

    public function all($args = []) {
        global $wpdb;

        $defaults = [
            'orderby' => 'id',
            'order' => 'DESC',
            'limit' => 20,
            'offset' => 0
        ];

        $args = wp_parse_args($args, $defaults);
        
        $query = "SELECT * FROM {$this->table}";
        
        if (!empty($args['where'])) {
            $query .= " WHERE " . $args['where'];
        }

        $query .= " ORDER BY {$args['orderby']} {$args['order']}";
        $query .= " LIMIT {$args['limit']} OFFSET {$args['offset']}";

        return array_map(
            fn($item) => new $this->model($item),
            $wpdb->get_results($query, ARRAY_A)
        );
    }

    public function create(array $data) {
        $model = new $this->model($data);
        $model->save();
        return $model;
    }

    public function update($id, array $data) {
        $model = $this->find($id);
        if ($model) {
            $model->fill($data);
            $model->save();
            $this->cache->delete("aura_{$this->table}_{$id}");
        }
        return $model;
    }

    public function delete($id) {
        global $wpdb;
        $this->cache->delete("aura_{$this->table}_{$id}");
        return $wpdb->delete($this->table, ['id' => $id]);
    }
}
