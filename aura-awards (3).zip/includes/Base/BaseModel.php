<?php

namespace Aura\Base;

abstract class BaseModel {
    protected $table;
    protected $primaryKey = 'id';
    protected $fillable = [];
    protected $hidden = [];
    protected $dates = ['created_at', 'updated_at'];

    public function __construct(array $attributes = []) {
        if (!empty($attributes)) {
            $this->fill($attributes);
        }
    }

    public function fill(array $attributes) {
        foreach ($attributes as $key => $value) {
            if (in_array($key, $this->fillable)) {
                $this->$key = $value;
            }
        }
    }

    public function toArray() {
        $array = get_object_vars($this);
        foreach ($this->hidden as $key) {
            unset($array[$key]);
        }
        return $array;
    }

    public function save() {
        global $wpdb;
        
        $data = $this->toArray();
        $data['updated_at'] = current_time('mysql');

        if (!isset($this->{$this->primaryKey})) {
            $data['created_at'] = current_time('mysql');
            return $wpdb->insert($this->table, $data);
        }

        return $wpdb->update(
            $this->table,
            $data,
            [$this->primaryKey => $this->{$this->primaryKey}]
        );
    }
}
