<?php
namespace Aura\Models;
use Aura\Base\BaseModel;

class User extends BaseModel {
    protected $table = 'aura_users';
    protected $fillable = ['wp_user_id', 'bio', 'website', 'social_links', 'preferences'];
}
