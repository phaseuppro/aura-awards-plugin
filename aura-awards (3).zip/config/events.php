<?php

return [
    'listeners' => [
        // Submission events
        'submission.created' => [
            'Aura\Listeners\Submission\NotifyAdminNewSubmission',
            'Aura\Listeners\Submission\ProcessSubmissionImages',
            'Aura\Listeners\Submission\UpdatePhotographerStats'
        ],
        'submission.approved' => [
            'Aura\Listeners\Submission\NotifyPhotographerApproval',
            'Aura\Listeners\Submission\AddToJudgingQueue'
        ],
        'submission.rejected' => [
            'Aura\Listeners\Submission\NotifyPhotographerRejection'
        ],

        // Judging events
        'judging.score_submitted' => [
            'Aura\Listeners\Judging\CalculateAverageScore',
            'Aura\Listeners\Judging\CheckAwardEligibility',
            'Aura\Listeners\Judging\NotifyPhotographerScore'
        ],
        'judging.completed' => [
            'Aura\Listeners\Judging\GenerateAwardCertificate',
            'Aura\Listeners\Judging\UpdateSubmissionStatus'
        ],

        // Award events
        'award.granted' => [
            'Aura\Listeners\Award\NotifyPhotographerAward',
            'Aura\Listeners\Award\GenerateAwardBadge',
            'Aura\Listeners\Award\UpdatePhotographerAchievements'
        ],

        // User events
        'user.registered' => [
            'Aura\Listeners\User\SendWelcomeEmail',
            'Aura\Listeners\User\CreateUserProfile'
        ],
        'user.role_changed' => [
            'Aura\Listeners\User\UpdateUserCapabilities',
            'Aura\Listeners\User\NotifyUserRoleChange'
        ]
    ],

    'subscribers' => [
        'Aura\Subscribers\ActivityLogSubscriber',
        'Aura\Subscribers\NotificationSubscriber',
        'Aura\Subscribers\StatisticsSubscriber'
    ]
];
