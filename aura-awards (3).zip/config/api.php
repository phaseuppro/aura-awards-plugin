<?php

return [
    'version' => '1',
    'prefix' => 'aura',
    
    'endpoints' => [
        'awards' => [
            'controller' => 'AwardController',
            'methods' => ['GET', 'POST', 'PUT', 'DELETE'],
            'args' => [
                'id' => [
                    'required' => false,
                    'validate_callback' => 'is_numeric'
                ]
            ]
        ],
        
        'submissions' => [
            'controller' => 'SubmissionController',
            'methods' => ['GET', 'POST', 'PUT', 'DELETE'],
            'args' => [
                'category' => [
                    'required' => false,
                    'sanitize_callback' => 'sanitize_text_field'
                ],
                'status' => [
                    'required' => false,
                    'enum' => ['pending', 'approved', 'rejected']
                ]
            ]
        ],
        
        'judging' => [
            'controller' => 'JudgingController',
            'methods' => ['GET', 'POST'],
            'args' => [
                'submission_id' => [
                    'required' => true,
                    'validate_callback' => 'is_numeric'
                ],
                'score' => [
                    'required' => true,
                    'validate_callback' => function($param) {
                        return is_numeric($param) && $param >= 0 && $param <= 100;
                    }
                ]
            ]
        ]
    ],
    
    'middleware' => [
        'auth' => 'AuthMiddleware',
        'rate_limit' => 'RateLimitMiddleware',
        'cache' => 'CacheMiddleware'
    ],
    
    'response' => [
        'format' => 'json',
        'pretty_print' => true,
        'headers' => [
            'Access-Control-Allow-Origin' => '*',
            'Access-Control-Allow-Methods' => 'GET, POST, PUT, DELETE',
            'Access-Control-Allow-Headers' => 'X-Requested-With, Content-Type, Authorization'
        ]
    ]
];
