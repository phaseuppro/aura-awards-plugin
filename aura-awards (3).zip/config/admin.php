<?php

return [
    'menu' => [
        'title' => 'AURA Awards',
        'icon' => 'dashicons-awards',
        'position' => 30,
        'items' => [
            'dashboard' => [
                'title' => 'Dashboard',
                'capability' => 'manage_options',
                'view' => 'admin/dashboard'
            ],
            'submissions' => [
                'title' => 'Submissions',
                'capability' => 'edit_posts',
                'view' => 'admin/submissions/index'
            ],
            'judging' => [
                'title' => 'Judging',
                'capability' => 'aura_judge_submissions',
                'view' => 'admin/judging/index'
            ],
            'awards' => [
                'title' => 'Awards',
                'capability' => 'aura_manage_awards',
                'view' => 'admin/awards/index'
            ],
            'users' => [
                'title' => 'Users',
                'capability' => 'manage_options',
                'view' => 'admin/users/index'
            ],
            'settings' => [
                'title' => 'Settings',
                'capability' => 'manage_options',
                'view' => 'admin/settings/index'
            ]
        ]
    ],

    'settings' => [
        'general' => [
            'title' => 'General Settings',
            'fields' => [
                'site_title' => [
                    'type' => 'text',
                    'label' => 'Site Title',
                    'default' => 'AURA Photography Awards'
                ],
                'submissions_open' => [
                    'type' => 'toggle',
                    'label' => 'Accept Submissions',
                    'default' => true
                ],
                'max_submissions' => [
                    'type' => 'number',
                    'label' => 'Max Submissions per User',
                    'default' => 5
                ]
            ]
        ],
        'judging' => [
            'title' => 'Judging Settings',
            'fields' => [
                'min_judges' => [
                    'type' => 'number',
                    'label' => 'Minimum Judges per Submission',
                    'default' => 3
                ],
                'scoring_system' => [
                    'type' => 'select',
                    'label' => 'Scoring System',
                    'options' => [
                        'percentage' => 'Percentage (0-100)',
                        'stars' => 'Stars (1-5)'
                    ],
                    'default' => 'percentage'
                ]
            ]
        ]
    ]
];
