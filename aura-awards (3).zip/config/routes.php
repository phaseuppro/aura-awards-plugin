<?php

return [
    'api' => [
        'namespace' => 'aura/v1',
        'routes' => [
            // Awards
            [
                'path' => '/awards',
                'method' => 'GET',
                'handler' => 'AwardController@index',
                'permission' => 'read'
            ],
            [
                'path' => '/awards/(?P<id>\d+)',
                'method' => 'GET',
                'handler' => 'AwardController@show',
                'permission' => 'read'
            ],
            
            // Submissions
            [
                'path' => '/submissions',
                'method' => 'GET',
                'handler' => 'SubmissionController@index',
                'permission' => 'read'
            ],
            [
                'path' => '/submissions',
                'method' => 'POST',
                'handler' => 'SubmissionController@store',
                'permission' => 'create'
            ],
            [
                'path' => '/submissions/(?P<id>\d+)',
                'method' => 'GET',
                'handler' => 'SubmissionController@show',
                'permission' => 'read'
            ],
            
            // Judging
            [
                'path' => '/judging/submissions',
                'method' => 'GET',
                'handler' => 'JudgingController@getPendingSubmissions',
                'permission' => 'judge'
            ],
            [
                'path' => '/judging/submit',
                'method' => 'POST',
                'handler' => 'JudgingController@submitScore',
                'permission' => 'judge'
            ],
            
            // User
            [
                'path' => '/user/profile',
                'method' => 'GET',
                'handler' => 'UserController@profile',
                'permission' => 'read'
            ],
            [
                'path' => '/user/submissions',
                'method' => 'GET',
                'handler' => 'UserController@submissions',
                'permission' => 'read'
            ]
        ]
    ],
    
    'admin' => [
        'pages' => [
            [
                'title' => 'AURA Awards',
                'slug' => 'aura-awards',
                'capability' => 'manage_options',
                'handler' => 'AdminController@dashboard'
            ],
            [
                'title' => 'Settings',
                'slug' => 'aura-awards-settings',
                'capability' => 'manage_options',
                'handler' => 'AdminController@settings'
            ]
        ]
    ]
];
