<?php
class Test_Aura_Ranking_System extends WP_UnitTestCase {
    private $ranking_system;
    private $test_users = array();
    private $test_submissions = array();

    public function setUp(): void {
        parent::setUp();
        
        $this->ranking_system = aura_ranking_system();
        
        // Create test users
        for ($i = 0; $i < 3; $i++) {
            $this->test_users[] = $this->factory->user->create(array(
                'role' => 'photographer'
            ));
        }
        
        // Create test submissions with different categories
        $categories = array('maternity', 'newborn', 'children');
        foreach ($this->test_users as $index => $user_id) {
            $this->test_submissions[] = $this->factory->post->create(array(
                'post_type' => 'aura_submission',
                'post_author' => $user_id,
                'meta_input' => array('category' => $categories[$index])
            ));
        }
    }

    public function test_update_rankings() {
        $vote_data = array(
            'submission_id' => $this->test_submissions[0],
            'points' => 85
        );

        $this->ranking_system->update_rankings($vote_data);

        global $wpdb;
        $table = $wpdb->prefix . 'aura_rankings';
        
        // Check overall ranking
        $overall_rank = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM $table WHERE user_id = %d AND type = 'overall'",
            $this->test_users[0]
        ));

        $this->assertEquals(85, $overall_rank->points);
        $this->assertEquals(1, $overall_rank->rank);
    }

    public function test_category_rankings() {
        // Add points to different categories
        $points = array(85, 78, 92);
        
        foreach ($this->test_submissions as $index => $submission_id) {
            $this->ranking_system->update_rankings(array(
                'submission_id' => $submission_id,
                'points' => $points[$index]
            ));
        }

        global $wpdb;
        $table = $wpdb->prefix . 'aura_rankings';
        
        // Check category rankings
        $category_ranks = $wpdb->get_results(
            "SELECT * FROM $table WHERE type = 'category' ORDER BY points DESC"
        );

        $this->assertEquals(3, count($category_ranks));
        $this->assertEquals(92, $category_ranks[0]->points);
    }

    public function test_seasonal_rankings() {
        $vote_data = array(
            'submission_id' => $this->test_submissions[0],
            'points' => 90
        );

        $this->ranking_system->update_rankings($vote_data);

        global $wpdb;
        $table = $wpdb->prefix . 'aura_rankings';
        
        $current_season = $this->get_current_season();
        $seasonal_rank = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM $table WHERE user_id = %d AND type = 'seasonal' AND season = %s",
            $this->test_users[0],
            $current_season
        ));

        $this->assertEquals(90, $seasonal_rank->points);
        $this->assertEquals(1, $seasonal_rank->rank);
    }

    private function get_current_season() {
        $month = date('n');
        if ($month >= 3 && $month <= 5) return 'spring';
        if ($month >= 6 && $month <= 8) return 'summer';
        if ($month >= 9 && $month <= 11) return 'autumn';
        return 'winter';
    }

    public function tearDown(): void {
        global $wpdb;
        $wpdb->query("TRUNCATE TABLE {$wpdb->prefix}aura_rankings");
        
        foreach ($this->test_submissions as $submission_id) {
            wp_delete_post($submission_id, true);
        }
        
        foreach ($this->test_users as $user_id) {
            wp_delete_user($user_id);
        }
        
        parent::tearDown();
    }
}
