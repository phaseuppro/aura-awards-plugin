<?php
class Test_Aura_Member_Types extends WP_UnitTestCase {
    private $member_types;
    private $test_user_id;

    public function setUp(): void {
        parent::setUp();
        
        $this->member_types = aura_member_types();
        
        $this->test_user_id = $this->factory->user->create(array(
            'role' => 'photographer'
        ));
    }

    public function test_register_member_types() {
        $this->member_types->register_member_types();
        
        $types = bp_get_member_types();
        
        $this->assertContains('novice', $types);
        $this->assertContains('enthusiast', $types);
        $this->assertContains('professional', $types);
        $this->assertContains('master', $types);
    }

    public function test_update_member_type() {
        // Set initial badges count
        update_user_meta($this->test_user_id, 'aura_badges', array(
            'gold' => 5,
            'silver' => 8,
            'bronze' => 12
        ));

        $this->member_types->update_member_type($this->test_user_id);
        
        $current_type = bp_get_member_type($this->test_user_id);
        $this->assertEquals('enthusiast', $current_type);
    }

    public function test_member_type_progression() {
        // Test Novice (default)
        $initial_type = bp_get_member_type($this->test_user_id);
        $this->assertEquals('novice', $initial_type);

        // Test progression to Enthusiast
        update_user_meta($this->test_user_id, 'aura_badges', array(
            'gold' => 3,
            'silver' => 5,
            'bronze' => 10
        ));
        $this->member_types->update_member_type($this->test_user_id);
        $this->assertEquals('enthusiast', bp_get_member_type($this->test_user_id));

        // Test progression to Professional
        update_user_meta($this->test_user_id, 'aura_badges', array(
            'gold' => 10,
            'silver' => 15,
            'bronze' => 20
        ));
        $this->member_types->update_member_type($this->test_user_id);
        $this->assertEquals('professional', bp_get_member_type($this->test_user_id));

        // Test progression to Master
        update_user_meta($this->test_user_id, 'aura_badges', array(
            'gold' => 25,
            'silver' => 35,
            'bronze' => 45
        ));
        $this->member_types->update_member_type($this->test_user_id);
        $this->assertEquals('master', bp_get_member_type($this->test_user_id));
    }

    public function test_get_member_type_requirements() {
        $requirements = $this->member_types->get_type_requirements('professional');
        
        $this->assertIsArray($requirements);
        $this->assertArrayHasKey('gold', $requirements);
        $this->assertArrayHasKey('silver', $requirements);
        $this->assertArrayHasKey('bronze', $requirements);
    }

    public function tearDown(): void {
        wp_delete_user($this->test_user_id);
        
        // Clean up member types
        $types = bp_get_member_types();
        foreach ($types as $type) {
            bp_unregister_member_type($type);
        }
        
        parent::tearDown();
    }
}
