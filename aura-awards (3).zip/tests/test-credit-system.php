<?php
class Test_Aura_Credit_System extends WP_UnitTestCase {
    private $credit_system;
    private $test_user_id;
    private $test_order_id;

    public function setUp(): void {
        parent::setUp();
        
        $this->credit_system = aura_credit_system();
        
        // Create test user
        $this->test_user_id = $this->factory->user->create(array(
            'role' => 'photographer'
        ));

        // Create test order
        $this->test_order_id = $this->create_test_order();
    }

    private function create_test_order() {
        $order = wc_create_order(array(
            'customer_id' => $this->test_user_id,
            'status' => 'pending'
        ));

        $product = $this->create_credit_product();
        $order->add_product($product, 1);
        $order->calculate_totals();
        
        return $order->get_id();
    }

    private function create_credit_product() {
        $product = new WC_Product_Simple();
        $product->set_name('Test Credit Package');
        $product->set_regular_price(25);
        $product->set_virtual(true);
        $product->save();

        update_post_meta($product->get_id(), '_aura_credits', 3);
        
        return $product;
    }

    public function test_credit_purchase() {
        $order = wc_get_order($this->test_order_id);
        $order->set_status('completed');
        $order->save();

        $user_credits = get_user_meta($this->test_user_id, 'aura_credits', true);
        $this->assertEquals(3, $user_credits);

        global $wpdb;
        $log_entry = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}aura_credit_log WHERE user_id = %d",
            $this->test_user_id
        ));

        $this->assertEquals('purchase', $log_entry->type);
        $this->assertEquals(3, $log_entry->credits);
    }

    public function test_deduct_credits() {
        // Add initial credits
        update_user_meta($this->test_user_id, 'aura_credits', 5);

        // Test successful deduction
        $result = $this->credit_system->deduct_credits($this->test_user_id, 2);
        $this->assertTrue($result);
        
        $remaining_credits = get_user_meta($this->test_user_id, 'aura_credits', true);
        $this->assertEquals(3, $remaining_credits);

        // Test insufficient credits
        $result = $this->credit_system->deduct_credits($this->test_user_id, 5);
        $this->assertFalse($result);
    }

    public function test_credit_log() {
        global $wpdb;
        $table = $wpdb->prefix . 'aura_credit_log';

        // Test purchase log
        $this->credit_system->process_credit_purchase($this->test_order_id);
        
        $purchase_log = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM $table WHERE user_id = %d AND type = 'purchase'",
            $this->test_user_id
        ));
        
        $this->assertNotNull($purchase_log);
        $this->assertEquals(3, $purchase_log->credits);

        // Test deduction log
        update_user_meta($this->test_user_id, 'aura_credits', 5);
        $this->credit_system->deduct_credits($this->test_user_id, 1);
        
        $deduction_log = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM $table WHERE user_id = %d AND type = 'deduction'",
            $this->test_user_id
        ));
        
        $this->assertNotNull($deduction_log);
        $this->assertEquals(1, $deduction_log->credits);
    }

    public function tearDown(): void {
        wp_delete_post($this->test_order_id, true);
        wp_delete_user($this->test_user_id);
        
        global $wpdb;
        $wpdb->query("TRUNCATE TABLE {$wpdb->prefix}aura_credit_log");
        
        parent::tearDown();
    }
}
