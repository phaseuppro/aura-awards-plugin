<?php
class Test_Aura_Badge_Manager extends WP_UnitTestCase {
    private $badge_manager;
    private $test_user_id;
    private $test_submission_id;
    private $test_image_path;

    public function setUp(): void {
        parent::setUp();
        
        $this->badge_manager = aura_badge_manager();
        
        // Create test user
        $this->test_user_id = $this->factory->user->create(array(
            'role' => 'photographer'
        ));
        
        // Create test submission
        $this->test_submission_id = $this->factory->post->create(array(
            'post_type' => 'aura_submission',
            'post_author' => $this->test_user_id
        ));

        // Create test image
        $this->test_image_path = $this->create_test_image();
        $this->attach_test_image();
    }

    private function create_test_image() {
        $upload_dir = wp_upload_dir();
        $test_image = $upload_dir['path'] . '/test-image.jpg';
        
        $image = imagecreatetruecolor(800, 600);
        imagejpeg($image, $test_image);
        imagedestroy($image);
        
        return $test_image;
    }

    private function attach_test_image() {
        $attachment_id = $this->factory->attachment->create_upload_object($this->test_image_path);
        set_post_thumbnail($this->test_submission_id, $attachment_id);
        return $attachment_id;
    }

    public function test_process_badge() {
        $vote_data = array(
            'submission_id' => $this->test_submission_id,
            'badge_level' => 'gold'
        );

        $this->badge_manager->process_badge($vote_data);

        // Check if badge was applied
        $has_badge = get_post_meta($this->test_submission_id, 'aura_badge_applied', true);
        $badge_position = get_post_meta($this->test_submission_id, 'aura_badge_position', true);
        $user_badges = get_user_meta($this->test_user_id, 'aura_badges', true);

        $this->assertTrue($has_badge);
        $this->assertEquals('bottom-right', $badge_position);
        $this->assertEquals(1, $user_badges['gold']);
    }

    public function test_update_badge_position() {
        $_POST['submission_id'] = $this->test_submission_id;
        $_POST['position'] = 'top-left';
        $_POST['nonce'] = wp_create_nonce('aura_badge_position');

        $this->badge_manager->update_badge_position();
        
        $new_position = get_post_meta($this->test_submission_id, 'aura_badge_position', true);
        $this->assertEquals('top-left', $new_position);
    }

    public function test_multiple_badges() {
        // Process first badge
        $this->badge_manager->process_badge([
            'submission_id' => $this->test_submission_id,
            'badge_level' => 'gold'
        ]);

        // Create second submission
        $second_submission = $this->factory->post->create([
            'post_type' => 'aura_submission',
            'post_author' => $this->test_user_id
        ]);

        // Process second badge
        $this->badge_manager->process_badge([
            'submission_id' => $second_submission,
            'badge_level' => 'gold'
        ]);

        $user_badges = get_user_meta($this->test_user_id, 'aura_badges', true);
        $this->assertEquals(2, $user_badges['gold']);
    }

    public function tearDown(): void {
        wp_delete_post($this->test_submission_id, true);
        wp_delete_user($this->test_user_id);
        unlink($this->test_image_path);
        parent::tearDown();
    }
}
