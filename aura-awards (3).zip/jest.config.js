module.exports = {
    testEnvironment: 'jsdom',
    roots: ['<rootDir>/tests/js'],
    moduleNameMapper: {
        '\\.(css|less|scss|sass)$': '<rootDir>/tests/js/__mocks__/styleMock.js',
        '\\.(gif|ttf|eot|svg|png)$': '<rootDir>/tests/js/__mocks__/fileMock.js'
    },
    setupFilesAfterEnv: ['<rootDir>/tests/js/setupTests.js'],
    testPathIgnorePatterns: ['/node_modules/', '/vendor/'],
    transform: {
        '^.+\\.jsx?$': 'babel-jest'
    },
    collectCoverage: true,
    collectCoverageFrom: [
        'admin/assets/js/**/*.js',
        'public/assets/js/**/*.js',
        '!**/node_modules/**',
        '!**/vendor/**'
    ],
    coverageReporters: ['text', 'lcov'],
    coverageDirectory: 'coverage',
    verbose: true,
    testTimeout: 10000,
    globals: {
        'wp': {},
        'jQuery': {},
        'window': {}
    }
};
