<?php
namespace Aura\Services;

use Aura\Base\Cache;

class SubmissionService {
    private $container;

    public function __construct($container) {
        $this->container = $container;
    }

    public function createSubmission($data) {
        global $wpdb;
        
        $result = $wpdb->insert(
            $wpdb->prefix . 'aura_submissions',
            $data,
            ['%d', '%d', '%s', '%s']
        );

        if ($result) {
            // Clear related caches
            Cache::delete('user_submissions_' . $data['user_id']);
            Cache::delete('award_submissions_' . $data['award_id']);
        }

        return $result ? $wpdb->insert_id : false;
    }

    public function getUserSubmissions($user_id) {
        $cache_key = 'user_submissions_' . $user_id;
        
        // Try to get from cache
        $cached_data = Cache::get($cache_key);
        if ($cached_data !== false) {
            return $cached_data;
        }

        global $wpdb;
        $submissions = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT * FROM {$wpdb->prefix}aura_submissions WHERE user_id = %d",
                $user_id
            )
        );

        // Store in cache
        Cache::set($cache_key, $submissions);

        return $submissions;
    }
}
