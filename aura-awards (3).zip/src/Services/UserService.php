<?php
namespace Aura\Services;

use Aura\Base\Cache;

class UserService {
    private $container;

    public function __construct($container) {
        $this->container = $container;
    }

    public function getUserCredits($user_id) {
        $cache_key = 'user_credits_' . $user_id;
        
        // Try to get from cache
        $cached_credits = Cache::get($cache_key);
        if ($cached_credits !== false) {
            return $cached_credits;
        }

        global $wpdb;
        $credits = $wpdb->get_var(
            $wpdb->prepare(
                "SELECT SUM(credits) FROM {$wpdb->prefix}aura_credits WHERE user_id = %d",
                $user_id
            )
        );

        // Store in cache
        Cache::set($cache_key, $credits);

        return (int)$credits;
    }

    public function addCredits($user_id, $amount, $type) {
        global $wpdb;
        
        $result = $wpdb->insert(
            $wpdb->prefix . 'aura_credits',
            [
                'user_id' => $user_id,
                'credits' => $amount,
                'transaction_type' => $type
            ],
            ['%d', '%d', '%s']
        );

        if ($result) {
            // Clear user credits cache
            Cache::delete('user_credits_' . $user_id);
        }

        return $result;
    }
}
