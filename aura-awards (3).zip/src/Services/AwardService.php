<?php
namespace Aura\Services;

use Aura\Base\Cache;

class AwardService {
    private $container;

    public function __construct($container) {
        $this->container = $container;
    }

    public function createAward($data) {
        $award_id = wp_insert_post([
            'post_type' => 'award',
            'post_title' => $data['title'],
            'post_content' => $data['description'],
            'post_status' => 'publish'
        ]);

        if ($award_id) {
            // Clear cache when new award is created
            Cache::delete('active_awards');
        }

        return $award_id;
    }

    public function getActiveAwards() {
        // Try to get from cache first
        $cached_awards = Cache::get('active_awards');
        
        if ($cached_awards !== false) {
            return $cached_awards;
        }

        $awards = get_posts([
            'post_type' => 'award',
            'post_status' => 'publish',
            'posts_per_page' => -1
        ]);

        // Store in cache for future requests
        Cache::set('active_awards', $awards);

        return $awards;
    }
}
