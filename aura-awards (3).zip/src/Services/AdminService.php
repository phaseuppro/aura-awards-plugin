<?php
namespace Aura\Services;

use Aura\Base\Cache;

class AdminService {
    private $container;

    public function __construct($container) {
        $this->container = $container;
    }

    public function getDashboardStats() {
        $cache_key = 'admin_dashboard_stats';
        
        // Try to get from cache
        $cached_stats = Cache::get($cache_key);
        if ($cached_stats !== false) {
            return $cached_stats;
        }

        global $wpdb;
        $stats = [
            'total_submissions' => $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}aura_submissions"),
            'total_judgments' => $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}aura_judgments"),
            'pending_submissions' => $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}aura_submissions WHERE status = 'pending'"),
            'total_credits' => $wpdb->get_var("SELECT SUM(credits) FROM {$wpdb->prefix}aura_credits")
        ];

        // Store in cache for 1 hour
        Cache::set($cache_key, $stats);

        return $stats;
    }

    public function getRecentActivity($limit = 10) {
        $cache_key = 'admin_recent_activity_' . $limit;
        
        $cached_activity = Cache::get($cache_key);
        if ($cached_activity !== false) {
            return $cached_activity;
        }

        global $wpdb;
        $activity = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT * FROM {$wpdb->prefix}aura_submissions 
                ORDER BY created_at DESC LIMIT %d",
                $limit
            )
        );

        Cache::set($cache_key, $activity);

        return $activity;
    }

    public function getAllSubmissions() {
        $cache_key = 'admin_all_submissions';
        
        $cached_submissions = Cache::get($cache_key);
        if ($cached_submissions !== false) {
            return $cached_submissions;
        }

        global $wpdb;
        $submissions = $wpdb->get_results(
            "SELECT s.*, u.display_name, a.post_title as award_title 
            FROM {$wpdb->prefix}aura_submissions s
            LEFT JOIN {$wpdb->users} u ON s.user_id = u.ID
            LEFT JOIN {$wpdb->posts} a ON s.award_id = a.ID
            ORDER BY s.created_at DESC"
        );

        Cache::set($cache_key, $submissions);

        return $submissions;
    }
}
