<?php
namespace Aura\Services;

use Aura\Base\Cache;

class JudgingService {
    private $container;

    public function __construct($container) {
        $this->container = $container;
    }

    public function submitJudgment($data) {
        global $wpdb;
        
        $result = $wpdb->insert(
            $wpdb->prefix . 'aura_judgments',
            $data,
            ['%d', '%d', '%d', '%s']
        );

        if ($result) {
            // Clear related caches
            Cache::delete('submission_judgments_' . $data['submission_id']);
            Cache::delete('judge_reviews_' . $data['judge_id']);
        }

        return $result ? $wpdb->insert_id : false;
    }

    public function getSubmissionJudgments($submission_id) {
        $cache_key = 'submission_judgments_' . $submission_id;
        
        // Try to get from cache
        $cached_data = Cache::get($cache_key);
        if ($cached_data !== false) {
            return $cached_data;
        }

        global $wpdb;
        $judgments = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT * FROM {$wpdb->prefix}aura_judgments WHERE submission_id = %d",
                $submission_id
            )
        );

        // Store in cache
        Cache::set($cache_key, $judgments);

        return $judgments;
    }
}
