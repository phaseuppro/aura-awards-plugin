<?php
namespace Aura\Base;

class Cache {
    private static $cache_group = 'aura_awards';
    private static $cache_expiry = 3600; // 1 hour

    public static function get($key) {
        return get_transient(self::getCacheKey($key));
    }

    public static function set($key, $value) {
        return set_transient(self::getCacheKey($key), $value, self::$cache_expiry);
    }

    public static function delete($key) {
        return delete_transient(self::getCacheKey($key));
    }

    private static function getCacheKey($key) {
        return self::$cache_group . '_' . $key;
    }
}
