<?php
namespace Aura\Base;

class Database {
    private static $db_version = '1.0.0';
    
    public static function createTables() {
        global $wpdb;
        $charset_collate = $wpdb->get_charset_collate();

        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');

        // Store current database version
        add_option('aura_awards_db_version', self::$db_version);

        $sql = [
            "CREATE TABLE IF NOT EXISTS {$wpdb->prefix}aura_submissions (
                id bigint(20) NOT NULL AUTO_INCREMENT,
                user_id bigint(20) NOT NULL,
                award_id bigint(20) NOT NULL,
                image_path varchar(255) NOT NULL,
                status varchar(20) DEFAULT 'pending',
                created_at datetime DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY  (id),
                KEY user_id (user_id),
                KEY award_id (award_id)
            ) $charset_collate;",

            "CREATE TABLE IF NOT EXISTS {$wpdb->prefix}aura_judgments (
                id bigint(20) NOT NULL AUTO_INCREMENT,
                submission_id bigint(20) NOT NULL,
                judge_id bigint(20) NOT NULL,
                score int(11) NOT NULL,
                feedback text,
                created_at datetime DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY  (id),
                KEY submission_id (submission_id),
                KEY judge_id (judge_id)
            ) $charset_collate;",

            "CREATE TABLE IF NOT EXISTS {$wpdb->prefix}aura_credits (
                id bigint(20) NOT NULL AUTO_INCREMENT,
                user_id bigint(20) NOT NULL,
                credits int(11) NOT NULL,
                transaction_type varchar(20) NOT NULL,
                created_at datetime DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY  (id),
                KEY user_id (user_id)
            ) $charset_collate;"
        ];

        foreach($sql as $query) {
            dbDelta($query);
        }
    }

    public static function checkUpdate() {
        $current_version = get_option('aura_awards_db_version', '0');
        
        if (version_compare($current_version, self::$db_version, '<')) {
            self::createTables();
            update_option('aura_awards_db_version', self::$db_version);
        }
    }
}
