<?php
namespace Aura\Base;

class AssetLoader {
    public static function init() {
        add_action('wp_enqueue_scripts', [self::class, 'loadFrontendAssets']);
        add_action('admin_enqueue_scripts', [self::class, 'loadAdminAssets']);
    }

    public static function loadFrontendAssets() {
        wp_enqueue_style(
            'aura-awards-style',
            AURA_PLUGIN_URL . 'assets/css/frontend.min.css',
            [],
            AURA_VERSION
        );

        wp_enqueue_script(
            'aura-awards-script',
            AURA_PLUGIN_URL . 'assets/js/frontend.min.js',
            ['jquery'],
            AURA_VERSION,
            true
        );

        wp_localize_script('aura-awards-script', 'auraAwards', [
            'ajaxUrl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('aura-awards-nonce')
        ]);
    }

    public static function loadAdminAssets($hook) {
        if (strpos($hook, 'aura-awards') === false) {
            return;
        }

        wp_enqueue_style(
            'aura-awards-admin',
            AURA_PLUGIN_URL . 'assets/css/admin.min.css',
            [],
            AURA_VERSION
        );

        wp_enqueue_script(
            'aura-awards-admin',
            AURA_PLUGIN_URL . 'assets/js/admin.min.js',
            ['jquery'],
            AURA_VERSION,
            true
        );
    }
}
