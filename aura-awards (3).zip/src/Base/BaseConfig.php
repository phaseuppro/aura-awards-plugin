<?php
namespace Aura\Base;

class BaseConfig {
    private $config = [];

    public function __construct() {
        $this->config = [
            'version' => AURA_VERSION,
            'plugin_dir' => AURA_PLUGIN_DIR,
            'plugin_url' => AURA_PLUGIN_URL,
            'max_submissions' => 10,
            'credits_per_submission' => 1,
            'judging_rounds' => ['preliminary', 'semifinal', 'final']
        ];
    }

    public function get($key) {
        return isset($this->config[$key]) ? $this->config[$key] : null;
    }

    public function set($key, $value) {
        $this->config[$key] = $value;
    }
}