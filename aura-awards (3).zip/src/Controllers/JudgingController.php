<?php
namespace Aura\Controllers;

class JudgingController {
    private $service;
    private $container;

    public function __construct($container) {
        $this->container = $container;
        $this->service = $container->get('JudgingService');
        $this->registerHooks();
    }

    private function registerHooks() {
        add_action('wp_ajax_submit_score', [$this, 'handleScoring']);
        add_action('init', [$this, 'registerJudgingRoles']);
    }

    public function registerJudgingRoles() {
        add_role('judge', 'Judge', [
            'read' => true,
            'judge_submissions' => true
        ]);
    }
}
