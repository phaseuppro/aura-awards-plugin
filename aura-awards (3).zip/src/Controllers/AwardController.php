<?php
namespace Aura\Controllers;

class AwardController {
    private $service;
    private $container;

    public function __construct($container) {
        $this->container = $container;
        $this->service = $container->get('AwardService');
        $this->registerHooks();
    }

    private function registerHooks() {
        add_action('init', [$this, 'registerPostType']);
        add_action('add_meta_boxes', [$this, 'addMetaBoxes']);
        add_action('save_post_award', [$this, 'saveMetaData']);
    }

    public function registerPostType() {
        register_post_type('award', [
            'public' => true,
            'label'  => 'Awards',
            'supports' => ['title', 'editor', 'thumbnail'],
            'menu_icon' => 'dashicons-awards'
        ]);
    }
}
