<?php
namespace Aura\Controllers;

class UserController {
    private $service;
    private $container;

    public function __construct($container) {
        $this->container = $container;
        $this->service = $container->get('UserService');
        $this->registerHooks();
    }

    private function registerHooks() {
        add_action('init', [$this, 'registerUserRoles']);
        add_action('bp_setup_nav', [$this, 'setupUserProfile']);
        add_action('wp_ajax_update_user_credits', [$this, 'handleCreditUpdate']);
    }

    public function registerUserRoles() {
        add_role('photographer', 'Photographer', [
            'read' => true,
            'upload_files' => true,
            'submit_photos' => true
        ]);
    }

    public function setupUserProfile() {
        bp_core_new_nav_item([
            'name' => 'Awards',
            'slug' => 'awards',
            'position' => 100,
            'screen_function' => [$this, 'displayAwardsTab']
        ]);
    }
}