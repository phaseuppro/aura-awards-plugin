module.exports = {
    plugins: [
        require('autoprefixer'),
        require('postcss-preset-env')({
            stage: 3,
            features: {
                'nesting-rules': true,
                'custom-media-queries': true,
                'custom-selectors': true
            }
        }),
        require('postcss-normalize'),
        require('postcss-sort-media-queries'),
        ...(process.env.NODE_ENV === 'production' ? [
            require('cssnano')({
                preset: ['default', {
                    discardComments: {
                        removeAll: true
                    },
                    normalizeWhitespace: true
                }]
            })
        ] : [])
    ]
};
