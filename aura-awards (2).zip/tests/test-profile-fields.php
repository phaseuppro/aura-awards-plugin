<?php
class Test_Aura_Profile_Fields extends WP_UnitTestCase {
    private $profile_fields;
    private $test_user_id;

    public function setUp(): void {
        parent::setUp();
        
        $this->profile_fields = aura_profile_fields();
        
        $this->test_user_id = $this->factory->user->create(array(
            'role' => 'photographer',
            'display_name' => 'Test Photographer'
        ));
    }

    public function test_register_profile_fields() {
        $this->profile_fields->register_fields();
        
        $field_groups = bp_xprofile_get_groups();
        $photography_group = false;
        
        foreach ($field_groups as $group) {
            if ($group->name === 'Photography Details') {
                $photography_group = $group;
                break;
            }
        }
        
        $this->assertNotFalse($photography_group);
        
        $fields = bp_xprofile_get_fields_by_group($photography_group->id);
        $field_names = wp_list_pluck($fields, 'name');
        
        $this->assertContains('Camera Model', $field_names);
        $this->assertContains('Photography Style', $field_names);
        $this->assertContains('Years of Experience', $field_names);
        $this->assertContains('Portfolio URL', $field_names);
    }

    public function test_save_profile_fields() {
        $field_data = array(
            'camera_model' => 'Canon EOS R5',
            'photography_style' => 'Portrait, Landscape',
            'years_experience' => '5',
            'portfolio_url' => 'https://example.com/portfolio'
        );

        foreach ($field_data as $field => $value) {
            $field_id = xprofile_get_field_id_from_name($field);
            xprofile_set_field_data($field_id, $this->test_user_id, $value);
        }

        foreach ($field_data as $field => $value) {
            $field_id = xprofile_get_field_id_from_name($field);
            $stored_value = bp_get_profile_field_data(array(
                'field' => $field_id,
                'user_id' => $this->test_user_id
            ));
            
            $this->assertEquals($value, $stored_value);
        }
    }

    public function test_field_validation() {
        $field_id = xprofile_get_field_id_from_name('portfolio_url');
        
        // Test valid URL
        $valid_url = 'https://example.com/portfolio';
        $is_valid = $this->profile_fields->validate_url_field($valid_url, $field_id);
        $this->assertTrue($is_valid);

        // Test invalid URL
        $invalid_url = 'not-a-url';
        $is_valid = $this->profile_fields->validate_url_field($invalid_url, $field_id);
        $this->assertFalse($is_valid);
    }

    public function test_field_visibility() {
        $fields = bp_xprofile_get_groups();
        
        foreach ($fields as $group) {
            if ($group->name === 'Photography Details') {
                $photography_fields = bp_xprofile_get_fields_by_group($group->id);
                
                foreach ($photography_fields as $field) {
                    $visibility = bp_xprofile_get_field_visibility_level($field->id, $this->test_user_id);
                    $this->assertEquals('public', $visibility);
                }
            }
        }
    }

    public function tearDown(): void {
        wp_delete_user($this->test_user_id);
        
        // Clean up field groups and fields
        $field_groups = bp_xprofile_get_groups();
        foreach ($field_groups as $group) {
            if ($group->name === 'Photography Details') {
                xprofile_delete_group($group->id);
            }
        }
        
        parent::tearDown();
    }
}
