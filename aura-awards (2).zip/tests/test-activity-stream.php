<?php
class Test_Aura_Activity_Stream extends WP_UnitTestCase {
    private $activity_stream;
    private $test_user_id;
    private $test_submission_id;

    public function setUp(): void {
        parent::setUp();
        
        $this->activity_stream = aura_activity_stream();
        
        // Create test user
        $this->test_user_id = $this->factory->user->create(array(
            'role' => 'photographer',
            'display_name' => 'Test Photographer'
        ));
        
        // Create test submission
        $this->test_submission_id = $this->factory->post->create(array(
            'post_type' => 'aura_submission',
            'post_author' => $this->test_user_id,
            'post_title' => 'Test Photo'
        ));
    }

    public function test_log_submission() {
        $activity_id = $this->activity_stream->log_activity(array(
            'type' => 'submission',
            'user_id' => $this->test_user_id,
            'submission_id' => $this->test_submission_id
        ));

        $activity = bp_activity_get(array('id' => $activity_id));
        
        $this->assertNotEmpty($activity['activities']);
        $this->assertEquals(
            'Test Photographer submitted a new photo: Test Photo',
            $activity['activities'][0]->content
        );
    }

    public function test_log_badge_earned() {
        $activity_id = $this->activity_stream->log_activity(array(
            'type' => 'badge',
            'user_id' => $this->test_user_id,
            'badge_level' => 'gold',
            'submission_id' => $this->test_submission_id
        ));

        $activity = bp_activity_get(array('id' => $activity_id));
        
        $this->assertNotEmpty($activity['activities']);
        $this->assertEquals(
            'Test Photographer earned a Gold badge for Test Photo',
            $activity['activities'][0]->content
        );
    }

    public function test_log_ranking_update() {
        $activity_id = $this->activity_stream->log_activity(array(
            'type' => 'ranking',
            'user_id' => $this->test_user_id,
            'rank' => 1,
            'category' => 'maternity'
        ));

        $activity = bp_activity_get(array('id' => $activity_id));
        
        $this->assertNotEmpty($activity['activities']);
        $this->assertEquals(
            'Test Photographer reached #1 rank in Maternity category',
            $activity['activities'][0]->content
        );
    }

    public function test_get_user_activity() {
        // Log multiple activities
        $this->activity_stream->log_activity(array(
            'type' => 'submission',
            'user_id' => $this->test_user_id,
            'submission_id' => $this->test_submission_id
        ));

        $this->activity_stream->log_activity(array(
            'type' => 'badge',
            'user_id' => $this->test_user_id,
            'badge_level' => 'gold',
            'submission_id' => $this->test_submission_id
        ));

        $activities = $this->activity_stream->get_user_activity($this->test_user_id);
        
        $this->assertEquals(2, count($activities));
    }

    public function tearDown(): void {
        wp_delete_post($this->test_submission_id, true);
        wp_delete_user($this->test_user_id);
        
        global $wpdb;
        $wpdb->query("TRUNCATE TABLE {$wpdb->prefix}bp_activity");
        $wpdb->query("TRUNCATE TABLE {$wpdb->prefix}bp_activity_meta");
        
        parent::tearDown();
    }
}
