<?php
require_once dirname(dirname(__FILE__)) . '/vendor/autoload.php';

$_tests_dir = getenv('WP_TESTS_DIR');
if (!$_tests_dir) {
    $_tests_dir = '/tmp/wordpress-tests-lib';
}

require_once $_tests_dir . '/includes/functions.php';

function _manually_load_environment() {
    require dirname(dirname(__FILE__)) . '/aura-awards.php';

    // Initialize BuddyPress
    require WP_PLUGIN_DIR . '/buddypress/bp-loader.php';
    
    // Initialize WooCommerce
    require WP_PLUGIN_DIR . '/woocommerce/woocommerce.php';
}

tests_add_filter('muplugins_loaded', '_manually_load_environment');

require $_tests_dir . '/includes/bootstrap.php';

// Activate plugins
activate_plugin('buddypress/bp-loader.php');
activate_plugin('woocommerce/woocommerce.php');
activate_plugin('aura-awards/aura-awards.php');

echo "Installing AURA AWARDS Test Suite..." . PHP_EOL;
