<?php
class Test_Aura_Submission_Handler extends WP_UnitTestCase {
    private $submission_handler;
    private $test_user_id;
    private $test_image_path;

    public function setUp(): void {
        parent::setUp();
        
        $this->submission_handler = aura_submission_handler();
        
        // Create test user with credits
        $this->test_user_id = $this->factory->user->create(array(
            'role' => 'photographer'
        ));
        update_user_meta($this->test_user_id, 'aura_credits', 5);
        
        // Create test image
        $this->test_image_path = $this->create_test_image();
    }

    private function create_test_image() {
        $upload_dir = wp_upload_dir();
        $test_image = $upload_dir['path'] . '/test-submission.jpg';
        
        $image = imagecreatetruecolor(2500, 2000);
        imagejpeg($image, $test_image, 90);
        imagedestroy($image);
        
        return $test_image;
    }

    public function test_valid_submission() {
        $_FILES['photo'] = array(
            'name' => 'test-submission.jpg',
            'type' => 'image/jpeg',
            'tmp_name' => $this->test_image_path,
            'error' => 0,
            'size' => filesize($this->test_image_path)
        );

        $_POST['category'] = 'maternity';
        $_POST['title'] = 'Test Submission';
        $_POST['description'] = 'Test Description';
        $_POST['nonce'] = wp_create_nonce('aura_submission');

        wp_set_current_user($this->test_user_id);

        $result = $this->submission_handler->process_submission();
        
        $this->assertTrue($result->success);
        $this->assertNotEmpty($result->data['submission_id']);

        $submission = get_post($result->data['submission_id']);
        $this->assertEquals('aura_submission', $submission->post_type);
        $this->assertEquals('pending', $submission->post_status);
        
        $remaining_credits = get_user_meta($this->test_user_id, 'aura_credits', true);
        $this->assertEquals(4, $remaining_credits);
    }

    public function test_invalid_image_type() {
        $_FILES['photo'] = array(
            'name' => 'test.png',
            'type' => 'image/png',
            'tmp_name' => $this->test_image_path,
            'error' => 0,
            'size' => filesize($this->test_image_path)
        );

        $_POST['nonce'] = wp_create_nonce('aura_submission');
        wp_set_current_user($this->test_user_id);

        $result = $this->submission_handler->process_submission();
        $this->assertFalse($result->success);
        $this->assertEquals('Invalid image type. Only JPEG allowed.', $result->data);
    }

    public function test_insufficient_credits() {
        update_user_meta($this->test_user_id, 'aura_credits', 0);

        $_FILES['photo'] = array(
            'name' => 'test-submission.jpg',
            'type' => 'image/jpeg',
            'tmp_name' => $this->test_image_path,
            'error' => 0,
            'size' => filesize($this->test_image_path)
        );

        $_POST['nonce'] = wp_create_nonce('aura_submission');
        wp_set_current_user($this->test_user_id);

        $result = $this->submission_handler->process_submission();
        $this->assertFalse($result->success);
        $this->assertEquals('Insufficient credits', $result->data);
    }

    public function tearDown(): void {
        wp_delete_user($this->test_user_id);
        unlink($this->test_image_path);
        
        $submissions = get_posts(array(
            'post_type' => 'aura_submission',
            'numberposts' => -1
        ));
        
        foreach ($submissions as $submission) {
            wp_delete_post($submission->ID, true);
        }
        
        parent::tearDown();
    }
}
