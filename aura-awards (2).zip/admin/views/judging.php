<div class="wrap aura-admin">
    <h1><?php _e('Judging Panel', 'aura-awards'); ?></h1>

    <div class="aura-judging-interface">
        <!-- Current Submission Display -->
        <div class="submission-display">
            <div class="image-container">
                <?php echo get_the_post_thumbnail($current_submission->ID, 'large'); ?>
                <div class="image-tools">
                    <button class="button zoom-in"><span class="dashicons dashicons-plus"></span></button>
                    <button class="button zoom-out"><span class="dashicons dashicons-minus"></span></button>
                    <button class="button full-screen"><span class="dashicons dashicons-fullscreen"></span></button>
                </div>
            </div>

            <div class="submission-info">
                <h3><?php echo get_the_title($current_submission->ID); ?></h3>
                <p class="photographer"><?php echo get_the_author_meta('display_name', $current_submission->post_author); ?></p>
                <p class="category"><?php echo get_post_meta($current_submission->ID, 'category', true); ?></p>
                <p class="date"><?php echo get_the_date('F j, Y', $current_submission->ID); ?></p>
            </div>
        </div>

        <!-- Judging Form -->
        <div class="judging-form">
            <form id="aura-judging-form">
                <input type="hidden" name="submission_id" value="<?php echo $current_submission->ID; ?>">
                
                <?php foreach ($judging_criteria as $criterion => $max_points): ?>
                    <div class="criterion-group">
                        <label for="<?php echo $criterion; ?>">
                            <?php echo ucfirst($criterion); ?> (0-<?php echo $max_points; ?>)
                        </label>
                        <div class="points-slider">
                            <input type="range" 
                                   id="<?php echo $criterion; ?>" 
                                   name="criteria[<?php echo $criterion; ?>]"
                                   min="0" 
                                   max="<?php echo $max_points; ?>" 
                                   value="0"
                                   class="slider">
                            <span class="points-display">0</span>
                        </div>
                    </div>
                <?php endforeach; ?>

                <div class="comments-section">
                    <label for="judge-comments"><?php _e('Comments', 'aura-awards'); ?></label>
                    <textarea id="judge-comments" name="comments"></textarea>
                </div>

                <div class="total-points">
                    <h3><?php _e('Total Points:', 'aura-awards'); ?> <span id="total-points">0</span></h3>
                </div>

                <div class="form-actions">
                    <button type="submit" class="button button-primary">
                        <?php _e('Submit Judgment', 'aura-awards'); ?>
                    </button>
                    <button type="button" class="button skip-submission">
                        <?php _e('Skip', 'aura-awards'); ?>
                    </button>
                </div>
            </form>
        </div>
    </div>

    <!-- Progress Indicator -->
    <div class="judging-progress">
        <div class="progress-bar">
            <div class="progress" style="width: <?php echo $progress_percentage; ?>%"></div>
        </div>
        <p><?php printf(__('Judged %d of %d submissions', 'aura-awards'), $judged_count, $total_submissions); ?></p>
    </div>
</div>
