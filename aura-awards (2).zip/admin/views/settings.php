<div class="wrap aura-admin">
    <h1><?php _e('AURA AWARDS Settings', 'aura-awards'); ?></h1>

    <nav class="nav-tab-wrapper">
        <?php foreach ($this->settings_tabs as $tab_id => $tab_name): ?>
            <a href="?page=aura-settings&tab=<?php echo $tab_id; ?>" 
               class="nav-tab <?php echo $active_tab === $tab_id ? 'nav-tab-active' : ''; ?>">
                <?php echo $tab_name; ?>
            </a>
        <?php endforeach; ?>
    </nav>

    <form method="post" action="options.php" class="aura-settings-form">
        <?php settings_fields('aura_options'); ?>
        
        <div class="tab-content">
            <?php switch($active_tab):
                case 'general': ?>
                    <div class="settings-section">
                        <h2><?php _e('General Settings', 'aura-awards'); ?></h2>
                        <table class="form-table">
                            <tr>
                                <th><?php _e('Enable Public Voting', 'aura-awards'); ?></th>
                                <td>
                                    <input type="checkbox" name="aura_settings[enable_public_voting]" 
                                           value="1" <?php checked(get_option('aura_settings')['enable_public_voting'], 1); ?>>
                                </td>
                            </tr>
                            <tr>
                                <th><?php _e('Contest Duration (days)', 'aura-awards'); ?></th>
                                <td>
                                    <input type="number" name="aura_settings[contest_duration]" 
                                           value="<?php echo esc_attr(get_option('aura_settings')['contest_duration']); ?>">
                                </td>
                            </tr>
                        </table>
                    </div>
                    <?php break;

                case 'submissions': ?>
                    <div class="settings-section">
                        <h2><?php _e('Submission Rules', 'aura-awards'); ?></h2>
                        <table class="form-table">
                            <tr>
                                <th><?php _e('Minimum Image Size', 'aura-awards'); ?></th>
                                <td>
                                    <input type="number" name="aura_settings[min_image_size]" 
                                           value="<?php echo esc_attr(get_option('aura_settings')['min_image_size']); ?>">
                                    <p class="description"><?php _e('Minimum width/height in pixels', 'aura-awards'); ?></p>
                                </td>
                            </tr>
                            <tr>
                                <th><?php _e('Maximum File Size (MB)', 'aura-awards'); ?></th>
                                <td>
                                    <input type="number" name="aura_settings[max_file_size]" 
                                           value="<?php echo esc_attr(get_option('aura_settings')['max_file_size']); ?>">
                                </td>
                            </tr>
                        </table>
                    </div>
                    <?php break;

                case 'judging': ?>
                    <div class="settings-section">
                        <h2><?php _e('Judging Criteria', 'aura-awards'); ?></h2>
                        <table class="form-table">
                            <?php foreach($this->get_judging_criteria() as $criterion => $weight): ?>
                                <tr>
                                    <th><?php echo ucfirst($criterion); ?> Weight</th>
                                    <td>
                                        <input type="number" name="aura_settings[criteria_weight][<?php echo $criterion; ?>]" 
                                               value="<?php echo esc_attr($weight); ?>" min="1" max="10">
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </table>
                    </div>
                    <?php break;

                case 'credits': ?>
                    <div class="settings-section">
                        <h2><?php _e('Credit Packages', 'aura-awards'); ?></h2>
                        <table class="form-table">
                            <?php foreach($this->get_credit_packages() as $package => $details): ?>
                                <tr>
                                    <th><?php echo $details['name']; ?></th>
                                    <td>
                                        <input type="number" name="aura_settings[credit_packages][<?php echo $package; ?>][price]" 
                                               value="<?php echo esc_attr($details['price']); ?>">
                                        <span class="description"><?php _e('Price ($)', 'aura-awards'); ?></span>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </table>
                    </div>
                    <?php break;

                case 'badges': ?>
                    <div class="settings-section">
                        <h2><?php _e('Badge Settings', 'aura-awards'); ?></h2>
                        <table class="form-table">
                            <tr>
                                <th><?php _e('Badge Size', 'aura-awards'); ?></th>
                                <td>
                                    <input type="number" name="aura_settings[badge_size]" 
                                           value="<?php echo esc_attr(get_option('aura_settings')['badge_size']); ?>">
                                    <p class="description"><?php _e('Size in pixels', 'aura-awards'); ?></p>
                                </td>
                            </tr>
                            <tr>
                                <th><?php _e('Default Position', 'aura-awards'); ?></th>
                                <td>
                                    <select name="aura_settings[badge_position]">
                                        <option value="top-left">Top Left</option>
                                        <option value="top-right">Top Right</option>
                                        <option value="bottom-left">Bottom Left</option>
                                        <option value="bottom-right">Bottom Right</option>
                                    </select>
                                </td>
                            </tr>
                        </table>
                    </div>
                    <?php break;
            endswitch; ?>
        </div>

        <?php submit_button(); ?>
    </form>
</div>
