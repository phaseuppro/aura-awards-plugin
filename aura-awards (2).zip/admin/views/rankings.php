<div class="wrap aura-admin">
    <h1><?php _e('AURA AWARDS Rankings', 'aura-awards'); ?></h1>

    <div class="aura-rankings-tabs">
        <nav class="nav-tab-wrapper">
            <a href="#overall" class="nav-tab nav-tab-active"><?php _e('Overall Rankings', 'aura-awards'); ?></a>
            <a href="#categories" class="nav-tab"><?php _e('Category Rankings', 'aura-awards'); ?></a>
            <a href="#seasonal" class="nav-tab"><?php _e('Seasonal Rankings', 'aura-awards'); ?></a>
        </nav>

        <!-- Overall Rankings Tab -->
        <div id="overall" class="tab-content active">
            <table class="wp-list-table widefat fixed striped">
                <thead>
                    <tr>
                        <th><?php _e('Rank', 'aura-awards'); ?></th>
                        <th><?php _e('Photographer', 'aura-awards'); ?></th>
                        <th><?php _e('Total Points', 'aura-awards'); ?></th>
                        <th><?php _e('Badges', 'aura-awards'); ?></th>
                        <th><?php _e('Submissions', 'aura-awards'); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($overall_rankings as $rank): ?>
                        <tr>
                            <td><?php echo $rank->position; ?></td>
                            <td><?php echo get_user_by('id', $rank->user_id)->display_name; ?></td>
                            <td><?php echo $rank->total_points; ?></td>
                            <td><?php echo $this->get_user_badges_count($rank->user_id); ?></td>
                            <td><?php echo $this->get_user_submissions_count($rank->user_id); ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>

        <!-- Category Rankings Tab -->
        <div id="categories" class="tab-content">
            <div class="category-selector">
                <select id="category-filter">
                    <?php foreach ($categories as $category): ?>
                        <option value="<?php echo esc_attr($category); ?>">
                            <?php echo esc_html(ucfirst($category)); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div id="category-rankings-table">
                <!-- Populated via AJAX -->
            </div>
        </div>

        <!-- Seasonal Rankings Tab -->
        <div id="seasonal" class="tab-content">
            <div class="season-selector">
                <select id="season-filter">
                    <?php foreach ($seasons as $season): ?>
                        <option value="<?php echo esc_attr($season); ?>">
                            <?php echo esc_html(ucfirst($season)); ?> <?php echo date('Y'); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div id="seasonal-rankings-table">
                <!-- Populated via AJAX -->
            </div>
        </div>
    </div>

    <!-- Export Options -->
    <div class="aura-export-options">
        <button class="button" id="export-csv">
            <?php _e('Export to CSV', 'aura-awards'); ?>
        </button>
        <button class="button" id="export-pdf">
            <?php _e('Export to PDF', 'aura-awards'); ?>
        </button>
    </div>
</div>
