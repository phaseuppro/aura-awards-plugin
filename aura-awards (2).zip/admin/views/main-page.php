<div class="wrap aura-admin">
    <h1>AURA AWARDS Dashboard</h1>
    
    <div class="aura-dashboard-grid">
        <div class="aura-card">
            <h2>Statistics</h2>
            <div class="aura-stats">
                <div class="stat-item">
                    <span class="stat-number"><?php echo $this->get_total_submissions(); ?></span>
                    <span class="stat-label">Total Submissions</span>
                </div>
                <div class="stat-item">
                    <span class="stat-number"><?php echo $this->get_active_photographers(); ?></span>
                    <span class="stat-label">Active Photographers</span>
                </div>
                <div class="stat-item">
                    <span class="stat-number"><?php echo $this->get_pending_judgments(); ?></span>
                    <span class="stat-label">Pending Judgments</span>
                </div>
            </div>
        </div>

        <div class="aura-card">
            <h2>Recent Submissions</h2>
            <?php $this->display_recent_submissions(); ?>
        </div>

        <div class="aura-card">
            <h2>Top Photographers</h2>
            <?php $this->display_top_photographers(); ?>
        </div>

        <div class="aura-card">
            <h2>Quick Actions</h2>
            <div class="aura-quick-actions">
                <a href="?page=aura-submissions" class="button button-primary">View Submissions</a>
                <a href="?page=aura-judging" class="button button-primary">Start Judging</a>
                <a href="?page=aura-rankings" class="button button-primary">View Rankings</a>
            </div>
        </div>
    </div>
</div>
