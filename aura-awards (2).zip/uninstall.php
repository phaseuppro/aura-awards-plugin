<?php
if (!defined('WP_UNINSTALL_PLUGIN')) {
    exit;
}

// Delete custom tables
global $wpdb;
$wpdb->query("DROP TABLE IF EXISTS {$wpdb->prefix}aura_rankings");
$wpdb->query("DROP TABLE IF EXISTS {$wpdb->prefix}aura_credit_log");

// Delete custom post type posts and metadata
$submissions = get_posts(array(
    'post_type' => 'aura_submission',
    'numberposts' => -1,
    'post_status' => 'any'
));

foreach ($submissions as $submission) {
    wp_delete_post($submission->ID, true);
}

// Delete user metadata
$users = get_users();
foreach ($users as $user) {
    delete_user_meta($user->ID, 'aura_credits');
    delete_user_meta($user->ID, 'aura_badges');
}

// Delete options
delete_option('aura_settings');
delete_option('aura_version');

// Remove custom roles
remove_role('photographer');

// Clear any scheduled hooks
wp_clear_scheduled_hook('aura_seasonal_reset');

// Delete uploaded badge images
$upload_dir = wp_upload_dir();
$badge_dir = $upload_dir['basedir'] . '/aura-badges';
if (is_dir($badge_dir)) {
    array_map('unlink', glob("$badge_dir/*.*"));
    rmdir($badge_dir);
}
