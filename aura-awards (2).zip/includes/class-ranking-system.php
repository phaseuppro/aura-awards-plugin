<?php
if (!defined('ABSPATH')) {
    exit;
}

class Aura_Ranking_System {
    private static $instance = null;
    private $seasons = array('spring', 'summer', 'autumn', 'winter');

    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        $this->init_hooks();
    }

    private function init_hooks() {
        add_action('aura_vote_completed', array($this, 'update_rankings'));
        add_action('init', array($this, 'schedule_seasonal_reset'));
        add_action('aura_seasonal_reset', array($this, 'reset_seasonal_rankings'));
    }

    public function update_rankings($vote_data) {
        $submission_id = $vote_data['submission_id'];
        $points = $vote_data['points'];
        $user_id = get_post_field('post_author', $submission_id);
        $category = get_post_meta($submission_id, 'category', true);
        
        // Update overall points
        $this->update_overall_ranking($user_id, $points);
        
        // Update category ranking
        $this->update_category_ranking($user_id, $category, $points);
        
        // Update seasonal ranking
        $this->update_seasonal_ranking($user_id, $points);
        
        // Calculate new positions
        $this->recalculate_rankings();
    }

    private function update_overall_ranking($user_id, $points) {
        global $wpdb;
        $table = $wpdb->prefix . 'aura_rankings';
        
        $wpdb->query($wpdb->prepare(
            "INSERT INTO $table (user_id, points, type) 
            VALUES (%d, %d, 'overall') 
            ON DUPLICATE KEY UPDATE points = points + %d",
            $user_id, $points, $points
        ));
    }

    private function update_category_ranking($user_id, $category, $points) {
        global $wpdb;
        $table = $wpdb->prefix . 'aura_rankings';
        
        $wpdb->query($wpdb->prepare(
            "INSERT INTO $table (user_id, category, points, type) 
            VALUES (%d, %s, %d, 'category') 
            ON DUPLICATE KEY UPDATE points = points + %d",
            $user_id, $category, $points, $points
        ));
    }

    private function update_seasonal_ranking($user_id, $points) {
        $current_season = $this->get_current_season();
        global $wpdb;
        $table = $wpdb->prefix . 'aura_rankings';
        
        $wpdb->query($wpdb->prepare(
            "INSERT INTO $table (user_id, points, season, type) 
            VALUES (%d, %d, %s, 'seasonal') 
            ON DUPLICATE KEY UPDATE points = points + %d",
            $user_id, $points, $current_season, $points
        ));
    }

    private function recalculate_rankings() {
        global $wpdb;
        $table = $wpdb->prefix . 'aura_rankings';
        
        // Update overall rankings
        $wpdb->query("SET @rank=0");
        $wpdb->query(
            "UPDATE $table SET rank = @rank:=@rank+1 
            WHERE type = 'overall' 
            ORDER BY points DESC"
        );
        
        // Update category rankings
        foreach ($this->get_categories() as $category) {
            $wpdb->query("SET @rank=0");
            $wpdb->query($wpdb->prepare(
                "UPDATE $table SET rank = @rank:=@rank+1 
                WHERE type = 'category' AND category = %s 
                ORDER BY points DESC",
                $category
            ));
        }
        
        // Update seasonal rankings
        $wpdb->query("SET @rank=0");
        $wpdb->query($wpdb->prepare(
            "UPDATE $table SET rank = @rank:=@rank+1 
            WHERE type = 'seasonal' AND season = %s 
            ORDER BY points DESC",
            $this->get_current_season()
        ));
    }

    private function get_current_season() {
        $month = date('n');
        if ($month >= 3 && $month <= 5) return 'spring';
        if ($month >= 6 && $month <= 8) return 'summer';
        if ($month >= 9 && $month <= 11) return 'autumn';
        return 'winter';
    }

    private function get_categories() {
        return array('maternity', 'newborn', 'children', 'family', 'ai-infused');
    }

    public function get_user_ranking($user_id, $type = 'overall', $category = '') {
        global $wpdb;
        $table = $wpdb->prefix . 'aura_rankings';
        
        $query = $wpdb->prepare(
            "SELECT rank, points FROM $table 
            WHERE user_id = %d AND type = %s",
            $user_id, $type
        );
        
        if ($category) {
            $query .= $wpdb->prepare(" AND category = %s", $category);
        }
        
        return $wpdb->get_row($query);
    }
}

// Initialize the class
function aura_ranking_system() {
    return Aura_Ranking_System::get_instance();
}
aura_ranking_system();
