<?php
namespace Aura\Database\Migrations;
use Aura\Base\BaseMigration;

class CreateJudgingTable extends BaseMigration {
    public function up() {
        $this->createTable($this->wpdb->prefix . 'aura_judging', "
            submission_id bigint(20) unsigned NOT NULL,
            judge_id bigint(20) unsigned NOT NULL,
            technical_score decimal(5,2) DEFAULT 0.00,
            artistic_score decimal(5,2) DEFAULT 0.00,
            feedback text,
            status varchar(20) DEFAULT 'pending'
        ");
    }

    public function down() {
        $this->dropTable($this->wpdb->prefix . 'aura_judging');
    }
}
