<?php
namespace Aura\Database\Migrations;
use Aura\Base\BaseMigration;

class CreateUserAwardsTable extends BaseMigration {
    public function up() {
        $this->createTable($this->wpdb->prefix . 'aura_user_awards', "
            user_id bigint(20) unsigned NOT NULL,
            award_id bigint(20) unsigned NOT NULL,
            awarded_at timestamp DEFAULT CURRENT_TIMESTAMP
        ");
    }

    public function down() {
        $this->dropTable($this->wpdb->prefix . 'aura_user_awards');
    }
}
