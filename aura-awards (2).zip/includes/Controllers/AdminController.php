<?php
namespace Aura\Controllers;
use Aura\Base\BaseController;

class AdminController extends BaseController {
    protected $adminService;

    public function __construct($container) {
        parent::__construct($container);
        $this->adminService = $container->get('AdminService');
    }

    public function dashboard() {
        return $this->json($this->adminService->getDashboardStats());
    }

    public function manageSubmissions() {
        return $this->json($this->adminService->getAllSubmissions());
    }

    public function manageJudges() {
        return $this->json($this->adminService->getAllJudges());
    }

    public function assignJudge() {
        return $this->json(
            $this->adminService->assignJudgeToSubmission(
                $this->request->get('submission_id'),
                $this->request->get('judge_id')
            )
        );
    }

    public function settings() {
        return $this->json($this->adminService->getSettings());
    }

    public function updateSettings() {
        return $this->json(
            $this->adminService->updateSettings($this->request->get())
        );
    }
}
