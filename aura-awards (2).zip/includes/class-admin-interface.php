<?php
if (!defined('ABSPATH')) {
    exit;
}

class Aura_Admin_Interface {
    private static $instance = null;
    private $settings_tabs = array();

    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        $this->setup_tabs();
        $this->init_hooks();
    }

    private function setup_tabs() {
        $this->settings_tabs = array(
            'general' => __('General Settings', 'aura-awards'),
            'submissions' => __('Submission Rules', 'aura-awards'),
            'judging' => __('Judging Criteria', 'aura-awards'),
            'credits' => __('Credit Packages', 'aura-awards'),
            'badges' => __('Badge Settings', 'aura-awards')
        );
    }

    private function init_hooks() {
        add_action('admin_menu', array($this, 'add_menu_pages'));
        add_action('admin_init', array($this, 'register_settings'));
        add_action('admin_enqueue_scripts', array($this, 'enqueue_admin_assets'));
        add_action('wp_ajax_aura_save_settings', array($this, 'save_settings'));
    }

    public function add_menu_pages() {
        add_menu_page(
            __('AURA AWARDS', 'aura-awards'),
            __('AURA AWARDS', 'aura-awards'),
            'manage_options',
            'aura-awards',
            array($this, 'render_dashboard'),
            'dashicons-awards',
            30
        );

        add_submenu_page(
            'aura-awards',
            __('Dashboard', 'aura-awards'),
            __('Dashboard', 'aura-awards'),
            'manage_options',
            'aura-awards'
        );

        add_submenu_page(
            'aura-awards',
            __('Settings', 'aura-awards'),
            __('Settings', 'aura-awards'),
            'manage_options',
            'aura-settings',
            array($this, 'render_settings')
        );
    }

    public function enqueue_admin_assets($hook) {
        if (strpos($hook, 'aura-') !== false) {
            wp_enqueue_style(
                'aura-admin-style',
                AURA_PLUGIN_URL . 'admin/assets/css/admin.css',
                array(),
                AURA_VERSION
            );

            wp_enqueue_script(
                'aura-admin-script',
                AURA_PLUGIN_URL . 'admin/assets/js/admin.js',
                array('jquery', 'jquery-ui-tabs'),
                AURA_VERSION,
                true
            );

            wp_localize_script('aura-admin-script', 'auraAdmin', array(
                'ajaxUrl' => admin_url('admin-ajax.php'),
                'nonce' => wp_create_nonce('aura_admin_nonce')
            ));
        }
    }

    public function render_dashboard() {
        $stats = $this->get_dashboard_stats();
        include AURA_PLUGIN_DIR . 'admin/views/dashboard.php';
    }

    public function render_settings() {
        $active_tab = isset($_GET['tab']) ? sanitize_text_field($_GET['tab']) : 'general';
        include AURA_PLUGIN_DIR . 'admin/views/settings.php';
    }

    private function get_dashboard_stats() {
        return array(
            'total_submissions' => $this->get_total_submissions(),
            'active_photographers' => $this->get_active_photographers(),
            'pending_judgments' => $this->get_pending_judgments(),
            'total_credits_sold' => $this->get_total_credits_sold()
        );
    }

    private function get_total_submissions() {
        return wp_count_posts('aura_submission')->publish;
    }

    private function get_active_photographers() {
        return count(get_users(array('role' => 'photographer')));
    }

    private function get_pending_judgments() {
        return wp_count_posts('aura_submission')->pending;
    }

    private function get_total_credits_sold() {
        global $wpdb;
        return $wpdb->get_var("SELECT SUM(credits) FROM {$wpdb->prefix}aura_credit_log WHERE type = 'purchase'");
    }
}

// Initialize the class
function aura_admin_interface() {
    return Aura_Admin_Interface::get_instance();
}
aura_admin_interface();
