<?php
if (!defined('ABSPATH')) {
    exit;
}

class Aura_Member_Types {
    private static $instance = null;

    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        $this->init_hooks();
    }

    private function init_hooks() {
        add_action('bp_register_member_types', array($this, 'register_member_types'));
        add_action('bp_signup_usermeta', array($this, 'add_signup_member_type'));
        add_filter('bp_get_member_type_directory_permalink', array($this, 'modify_member_directory_url'), 10, 2);
    }

    public function register_member_types() {
        bp_register_member_type('photographer', array(
            'labels' => array(
                'name'          => _x('Photographers', 'Member type label', 'aura-awards'),
                'singular_name' => _x('Photographer', 'Member type singular label', 'aura-awards'),
            ),
            'has_directory' => true,
            'show_in_list'  => true,
            'description'   => __('Professional photographers participating in AURA AWARDS', 'aura-awards'),
        ));
    }

    public function add_signup_member_type($usermeta) {
        $usermeta['member_type'] = 'photographer';
        return $usermeta;
    }

    public function modify_member_directory_url($url, $member_type) {
        if ($member_type === 'photographer') {
            return home_url('/photographers/');
        }
        return $url;
    }

    public function get_photographer_count() {
        return bp_core_get_users(array(
            'member_type' => 'photographer',
            'count_total' => true,
        ));
    }

    public function get_active_photographers() {
        return bp_core_get_users(array(
            'member_type'  => 'photographer',
            'type'         => 'active',
            'per_page'     => -1,
        ));
    }
}

// Initialize the class
function aura_member_types() {
    return Aura_Member_Types::get_instance();
}
aura_member_types();
