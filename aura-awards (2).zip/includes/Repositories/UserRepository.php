<?php
namespace Aura\Repositories;
use Aura\Base\BaseRepository;
use Aura\Models\User;

class UserRepository extends BaseRepository {
    protected $model = User::class;

    public function findByWpUserId($wpUserId) {
        return $this->findWhere(['wp_user_id' => $wpUserId]);
    }

    public function getUserSubmissions($userId) {
        global $wpdb;
        return $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM aura_submissions WHERE user_id = %d",
            $userId
        ));
    }

    public function getUserAwards($userId) {
        global $wpdb;
        return $wpdb->get_results($wpdb->prepare(
            "SELECT a.* FROM aura_awards a 
            JOIN aura_user_awards ua ON ua.award_id = a.id 
            WHERE ua.user_id = %d",
            $userId
        ));
    }
}
