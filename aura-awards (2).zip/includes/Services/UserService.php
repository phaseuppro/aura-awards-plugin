<?php
namespace Aura\Services;
use Aura\Base\BaseService;

class UserService extends BaseService {
    protected $userRepo;

    public function __construct($container) {
        parent::__construct($container);
        $this->userRepo = $container->get('UserRepository');
    }

    public function getCurrentUserProfile() {
        return $this->userRepo->findByWpUserId(get_current_user_id());
    }

    public function updateProfile($data) {
        $this->validate($data, [
            'bio' => 'string|max:500',
            'website' => 'url',
            'social_links' => 'array'
        ]);

        return $this->userRepo->updateByWpUserId(get_current_user_id(), $data);
    }

    public function getUserSubmissions() {
        return $this->userRepo->getUserSubmissions(get_current_user_id());
    }

    public function getUserAwards() {
        return $this->userRepo->getUserAwards(get_current_user_id());
    }
}
