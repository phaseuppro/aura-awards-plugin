<?php
if (!defined('ABSPATH')) {
    exit;
}

class Aura_Voting_System {
    private static $instance = null;
    private $criteria = array(
        'light' => 10,
        'pose' => 10,
        'idea' => 10,
        'colors' => 10,
        'material' => 10,
        'emotion' => 10
    );

    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        $this->init_hooks();
    }

    private function init_hooks() {
        add_action('wp_ajax_submit_vote', array($this, 'handle_vote_submission'));
        add_action('admin_menu', array($this, 'add_voting_menu'));
        add_action('admin_enqueue_scripts', array($this, 'enqueue_voting_assets'));
    }

    public function add_voting_menu() {
        add_submenu_page(
            'edit.php?post_type=aura_submission',
            __('Judge Submissions', 'aura-awards'),
            __('Judge Submissions', 'aura-awards'),
            'manage_options',
            'aura-voting',
            array($this, 'render_voting_page')
        );
    }

    public function render_voting_page() {
        $submissions = $this->get_pending_submissions();
        include AURA_PLUGIN_DIR . 'admin/views/voting-page.php';
    }

    public function handle_vote_submission() {
        check_ajax_referer('aura_voting', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(__('Unauthorized access', 'aura-awards'));
        }

        $submission_id = intval($_POST['submission_id']);
        $votes = $this->sanitize_votes($_POST['votes']);
        
        $total_points = $this->calculate_points($votes);
        $badge_level = $this->determine_badge_level($total_points);
        
        $this->save_votes($submission_id, $votes, $total_points, $badge_level);

        do_action('aura_vote_completed', array(
            'submission_id' => $submission_id,
            'points' => $total_points,
            'badge_level' => $badge_level
        ));

        wp_send_json_success(array(
            'message' => __('Vote saved successfully', 'aura-awards'),
            'points' => $total_points,
            'badge' => $badge_level
        ));
    }

    private function sanitize_votes($votes) {
        $sanitized = array();
        foreach ($this->criteria as $criterion => $max_value) {
            if (isset($votes[$criterion])) {
                $sanitized[$criterion] = min(max(0, intval($votes[$criterion])), $max_value);
            }
        }
        return $sanitized;
    }

    private function calculate_points($votes) {
        $total = 0;
        foreach ($votes as $criterion => $value) {
            $total += $value;
        }
        return ($total / 60) * 100; // Convert to percentage
    }

    private function determine_badge_level($points) {
        if ($points >= 81) return 'platinum';
        if ($points >= 61) return 'gold';
        if ($points >= 31) return 'silver';
        return 'bronze';
    }

    private function save_votes($submission_id, $votes, $total_points, $badge_level) {
        update_post_meta($submission_id, 'aura_votes', $votes);
        update_post_meta($submission_id, 'aura_total_points', $total_points);
        update_post_meta($submission_id, 'aura_badge_level', $badge_level);
        
        wp_update_post(array(
            'ID' => $submission_id,
            'post_status' => 'publish'
        ));
    }

    private function get_pending_submissions() {
        return get_posts(array(
            'post_type' => 'aura_submission',
            'post_status' => 'pending',
            'posts_per_page' => -1
        ));
    }
}

// Initialize the class
function aura_voting_system() {
    return Aura_Voting_System::get_instance();
}
aura_voting_system();
