<?php
namespace Aura\Models;
use Aura\Base\BaseModel;

class Submission extends BaseModel {
    protected $table = 'aura_submissions';
    protected $fillable = ['title', 'description', 'user_id', 'category_id', 'image_url', 'status', 'score'];
}
