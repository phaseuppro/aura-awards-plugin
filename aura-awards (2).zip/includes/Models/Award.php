<?php
namespace Aura\Models;
use Aura\Base\BaseModel;

class Award extends BaseModel {
    protected $table = 'aura_awards';
    protected $fillable = ['title', 'description', 'category_id', 'points', 'badge_url', 'status'];
}
