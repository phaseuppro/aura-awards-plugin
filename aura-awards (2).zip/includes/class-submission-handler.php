<?php
if (!defined('ABSPATH')) {
    exit;
}

class Aura_Submission_Handler {
    private static $instance = null;
    private $allowed_image_types = array('image/jpeg');
    private $image_requirements = array(
        'min_size' => 2028,
        'max_size' => 4000,
        'max_file_size' => 5242880 // 5MB in bytes
    );

    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        $this->init_hooks();
    }

    private function init_hooks() {
        add_action('wp_ajax_submit_photo', array($this, 'handle_submission'));
        add_action('init', array($this, 'register_submission_post_type'));
        add_filter('upload_mimes', array($this, 'restrict_upload_mimes'));
    }

    public function register_submission_post_type() {
        register_post_type('aura_submission', array(
            'labels' => array(
                'name' => __('Submissions', 'aura-awards'),
                'singular_name' => __('Submission', 'aura-awards')
            ),
            'public' => false,
            'show_ui' => true,
            'capability_type' => 'post',
            'supports' => array('title', 'thumbnail'),
            'menu_icon' => 'dashicons-format-image'
        ));
    }

    public function handle_submission() {
        check_ajax_referer('aura_submission', 'nonce');

        if (!$this->can_user_submit()) {
            wp_send_json_error(__('Insufficient credits', 'aura-awards'));
        }

        $image = $_FILES['photo'];
        $category = sanitize_text_field($_POST['category']);

        // Validate submission
        $validation = $this->validate_submission($image, $category);
        if (is_wp_error($validation)) {
            wp_send_json_error($validation->get_error_message());
        }

        // Process image
        $attachment_id = $this->process_image($image);
        if (is_wp_error($attachment_id)) {
            wp_send_json_error($attachment_id->get_error_message());
        }

        // Create submission
        $submission_id = $this->create_submission($attachment_id, $category);
        if (is_wp_error($submission_id)) {
            wp_send_json_error($submission_id->get_error_message());
        }

        // Deduct credit
        $this->deduct_credit();

        do_action('aura_photo_submitted', array(
            'submission_id' => $submission_id,
            'category' => $category,
            'user_id' => get_current_user_id()
        ));

        wp_send_json_success(array(
            'message' => __('Submission successful', 'aura-awards'),
            'submission_id' => $submission_id
        ));
    }

    private function validate_submission($image, $category) {
        // Check image type
        if (!in_array($image['type'], $this->allowed_image_types)) {
            return new WP_Error('invalid_type', __('Invalid image type. Only JPEG allowed.', 'aura-awards'));
        }

        // Check file size
        if ($image['size'] > $this->image_requirements['max_file_size']) {
            return new WP_Error('file_too_large', __('Image file size exceeds 5MB limit.', 'aura-awards'));
        }

        // Check dimensions
        $image_size = getimagesize($image['tmp_name']);
        if ($image_size[0] < $this->image_requirements['min_size'] || 
            $image_size[1] < $this->image_requirements['min_size']) {
            return new WP_Error('image_too_small', __('Image dimensions too small.', 'aura-awards'));
        }

        if ($image_size[0] > $this->image_requirements['max_size'] || 
            $image_size[1] > $this->image_requirements['max_size']) {
            return new WP_Error('image_too_large', __('Image dimensions too large.', 'aura-awards'));
        }

        return true;
    }

    private function process_image($image) {
        require_once(ABSPATH . 'wp-admin/includes/image.php');
        require_once(ABSPATH . 'wp-admin/includes/file.php');
        require_once(ABSPATH . 'wp-admin/includes/media.php');

        $attachment_id = media_handle_upload('photo', 0);

        if (is_wp_error($attachment_id)) {
            return $attachment_id;
        }

        return $attachment_id;
    }

    private function create_submission($attachment_id, $category) {
        $submission = wp_insert_post(array(
            'post_type' => 'aura_submission',
            'post_status' => 'pending',
            'post_author' => get_current_user_id(),
            'post_title' => sprintf(__('Submission in %s', 'aura-awards'), $category)
        ));

        if (is_wp_error($submission)) {
            return $submission;
        }

        set_post_thumbnail($submission, $attachment_id);
        update_post_meta($submission, 'category', $category);

        return $submission;
    }

    private function can_user_submit() {
        $credits = get_user_meta(get_current_user_id(), 'aura_credits', true);
        return $credits > 0;
    }

    private function deduct_credit() {
        $credits = get_user_meta(get_current_user_id(), 'aura_credits', true);
        update_user_meta(get_current_user_id(), 'aura_credits', $credits - 1);
    }
}

// Initialize the class
function aura_submission_handler() {
    return Aura_Submission_Handler::get_instance();
}
aura_submission_handler();

