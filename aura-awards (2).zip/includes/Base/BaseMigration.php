<?php

namespace Aura\Base;

abstract class BaseMigration {
    protected $wpdb;
    protected $charset_collate;
    protected $table;

    public function __construct() {
        global $wpdb;
        $this->wpdb = $wpdb;
        $this->charset_collate = $wpdb->get_charset_collate();
    }

    abstract public function up();
    abstract public function down();

    protected function createTable($table, $columns) {
        $sql = "CREATE TABLE IF NOT EXISTS {$table} (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            {$columns},
            created_at timestamp NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY  (id)
        ) {$this->charset_collate};";

        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql);
    }

    protected function dropTable($table) {
        $sql = "DROP TABLE IF EXISTS {$table}";
        $this->wpdb->query($sql);
    }

    protected function addColumn($table, $column, $definition) {
        if (!$this->columnExists($table, $column)) {
            $sql = "ALTER TABLE {$table} ADD {$column} {$definition}";
            $this->wpdb->query($sql);
        }
    }

    protected function dropColumn($table, $column) {
        if ($this->columnExists($table, $column)) {
            $sql = "ALTER TABLE {$table} DROP COLUMN {$column}";
            $this->wpdb->query($sql);
        }
    }

    protected function addIndex($table, $column, $name = null) {
        $name = $name ?: "idx_{$table}_{$column}";
        $sql = "ALTER TABLE {$table} ADD INDEX {$name} ({$column})";
        $this->wpdb->query($sql);
    }

    protected function dropIndex($table, $name) {
        $sql = "ALTER TABLE {$table} DROP INDEX {$name}";
        $this->wpdb->query($sql);
    }

    protected function columnExists($table, $column) {
        $sql = "SHOW COLUMNS FROM {$table} LIKE '{$column}'";
        return (bool) $this->wpdb->get_results($sql);
    }
}
