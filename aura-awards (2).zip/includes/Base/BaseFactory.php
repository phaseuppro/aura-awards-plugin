<?php

namespace Aura\Base;

class BaseFactory {
    protected $container;
    protected $defaults = [];

    public function __construct($container) {
        $this->container = $container;
    }

    public function make($class, array $parameters = []) {
        $parameters = array_merge($this->defaults, $parameters);
        
        if (!class_exists($class)) {
            throw new BaseException("Class {$class} not found");
        }

        $reflector = new \ReflectionClass($class);
        
        if (!$reflector->isInstantiable()) {
            throw new BaseException("Class {$class} is not instantiable");
        }

        $constructor = $reflector->getConstructor();
        
        if (is_null($constructor)) {
            return new $class;
        }

        $dependencies = $this->resolveDependencies($constructor, $parameters);
        
        return $reflector->newInstanceArgs($dependencies);
    }

    protected function resolveDependencies(\ReflectionMethod $constructor, array $parameters) {
        $dependencies = [];

        foreach ($constructor->getParameters() as $parameter) {
            $name = $parameter->getName();
            $type = $parameter->getType();

            if (isset($parameters[$name])) {
                $dependencies[] = $parameters[$name];
                continue;
            }

            if ($type && !$type->isBuiltin()) {
                $dependencies[] = $this->container->get($type->getName());
                continue;
            }

            if ($parameter->isDefaultValueAvailable()) {
                $dependencies[] = $parameter->getDefaultValue();
                continue;
            }

            throw new BaseException("Cannot resolve dependency: {$name}");
        }

        return $dependencies;
    }
}
