<?php

namespace Aura\Base;

abstract class BaseSeeder {
    protected $wpdb;
    protected $faker;
    protected $container;

    public function __construct($container) {
        global $wpdb;
        $this->wpdb = $wpdb;
        $this->container = $container;
        $this->faker = \Faker\Factory::create();
    }

    abstract public function run();

    protected function table($table) {
        return $this->wpdb->prefix . $table;
    }

    protected function insert($table, $data) {
        return $this->wpdb->insert(
            $this->table($table),
            array_merge($data, [
                'created_at' => current_time('mysql'),
                'updated_at' => current_time('mysql')
            ])
        );
    }

    protected function insertMany($table, $records) {
        foreach ($records as $record) {
            $this->insert($table, $record);
        }
    }

    protected function truncate($table) {
        return $this->wpdb->query("TRUNCATE TABLE " . $this->table($table));
    }

    protected function createUser($data) {
        return wp_insert_user(array_merge([
            'user_pass' => wp_generate_password(),
            'role' => 'subscriber'
        ], $data));
    }

    protected function createPost($data) {
        return wp_insert_post(array_merge([
            'post_status' => 'publish',
            'post_type' => 'post'
        ], $data));
    }
}
