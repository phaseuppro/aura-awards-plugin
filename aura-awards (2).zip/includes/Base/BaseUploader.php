<?php

namespace Aura\Base;

class BaseUploader {
    protected $container;
    protected $config;
    protected $allowedTypes;
    protected $maxSize;
    protected $uploadDir;

    public function __construct($container) {
        $this->container = $container;
        $this->config = $container->get('config')->get('images');
        $this->allowedTypes = $this->config['allowed_types'];
        $this->maxSize = $this->config['max_size'];
        $this->uploadDir = wp_upload_dir()['basedir'] . '/aura-awards';
        
        $this->ensureUploadDirectoryExists();
    }

    public function upload($file, $directory = '') {
        $this->validateFile($file);
        
        $filename = $this->generateFilename($file['name']);
        $targetPath = $this->uploadDir . '/' . $directory . '/' . $filename;

        if (move_uploaded_file($file['tmp_name'], $targetPath)) {
            return [
                'filename' => $filename,
                'path' => $targetPath,
                'url' => wp_upload_dir()['baseurl'] . '/aura-awards/' . $directory . '/' . $filename
            ];
        }

        throw new BaseException('Failed to upload file');
    }

    public function delete($filename, $directory = '') {
        $filepath = $this->uploadDir . '/' . $directory . '/' . $filename;
        
        if (file_exists($filepath)) {
            return unlink($filepath);
        }
        
        return false;
    }

    protected function validateFile($file) {
        if (!isset($file['tmp_name']) || !is_uploaded_file($file['tmp_name'])) {
            throw new BaseException('Invalid upload');
        }

        $type = wp_check_filetype($file['name'])['ext'];
        if (!in_array($type, $this->allowedTypes)) {
            throw new BaseException('File type not allowed');
        }

        if ($file['size'] > $this->maxSize) {
            throw new BaseException('File size exceeds limit');
        }
    }

    protected function generateFilename($originalName) {
        $extension = pathinfo($originalName, PATHINFO_EXTENSION);
        return uniqid() . '_' . time() . '.' . $extension;
    }

    protected function ensureUploadDirectoryExists() {
        if (!file_exists($this->uploadDir)) {
            wp_mkdir_p($this->uploadDir);
        }
    }
}
