<?php

namespace Aura\Base;

class BaseLogger {
    protected $logFile;
    protected $dateFormat = 'Y-m-d H:i:s';
    protected $levels = [
        'emergency' => 0,
        'alert'     => 1,
        'critical'  => 2,
        'error'     => 3,
        'warning'   => 4,
        'notice'    => 5,
        'info'      => 6,
        'debug'     => 7
    ];

    public function __construct($container) {
        $config = $container->get('config')->get('logging');
        $this->logFile = $config['path'];
        $this->ensureLogFileExists();
    }

    public function log($level, $message, array $context = []) {
        $entry = $this->formatEntry($level, $message, $context);
        $this->write($entry);
    }

    public function emergency($message, array $context = []) {
        $this->log('emergency', $message, $context);
    }

    public function alert($message, array $context = []) {
        $this->log('alert', $message, $context);
    }

    public function critical($message, array $context = []) {
        $this->log('critical', $message, $context);
    }

    public function error($message, array $context = []) {
        $this->log('error', $message, $context);
    }

    public function warning($message, array $context = []) {
        $this->log('warning', $message, $context);
    }

    public function notice($message, array $context = []) {
        $this->log('notice', $message, $context);
    }

    public function info($message, array $context = []) {
        $this->log('info', $message, $context);
    }

    public function debug($message, array $context = []) {
        $this->log('debug', $message, $context);
    }

    protected function formatEntry($level, $message, array $context = []) {
        $datetime = date($this->dateFormat);
        $message = $this->interpolate($message, $context);
        return sprintf(
            "[%s] %s: %s\n",
            $datetime,
            strtoupper($level),
            $message
        );
    }

    protected function interpolate($message, array $context = []) {
        $replace = [];
        foreach ($context as $key => $val) {
            $replace['{' . $key . '}'] = $this->normalize($val);
        }
        return strtr($message, $replace);
    }

    protected function normalize($data) {
        if (is_array($data) || is_object($data)) {
            return json_encode($data);
        }
        return $data;
    }

    protected function write($entry) {
        file_put_contents($this->logFile, $entry, FILE_APPEND | LOCK_EX);
    }

    protected function ensureLogFileExists() {
        $dir = dirname($this->logFile);
        if (!is_dir($dir)) {
            mkdir($dir, 0755, true);
        }
        if (!file_exists($this->logFile)) {
            touch($this->logFile);
            chmod($this->logFile, 0644);
        }
    }
}
