<?php

namespace Aura\Base;

class BaseScheduler {
    protected $container;
    protected $schedules = [];
    protected $prefix = 'aura_';

    public function __construct($container) {
        $this->container = $container;
        add_filter('cron_schedules', [$this, 'addSchedules']);
    }

    public function schedule($name, $interval, $callback, $args = []) {
        $hook = $this->prefix . $name;
        
        if (!wp_next_scheduled($hook, $args)) {
            wp_schedule_event(time(), $interval, $hook, $args);
        }

        add_action($hook, $callback);
        return $this;
    }

    public function daily($name, $callback, $args = []) {
        return $this->schedule($name, 'daily', $callback, $args);
    }

    public function hourly($name, $callback, $args = []) {
        return $this->schedule($name, 'hourly', $callback, $args);
    }

    public function everyMinutes($minutes, $name, $callback, $args = []) {
        $this->addSchedule("every_{$minutes}_minutes", $minutes * 60);
        return $this->schedule($name, "every_{$minutes}_minutes", $callback, $args);
    }

    public function unschedule($name) {
        $hook = $this->prefix . $name;
        $timestamp = wp_next_scheduled($hook);
        
        if ($timestamp) {
            wp_unschedule_event($timestamp, $hook);
        }
        
        return $this;
    }

    protected function addSchedule($name, $interval) {
        $this->schedules[$name] = [
            'interval' => $interval,
            'display' => sprintf(__('Every %d minutes'), $interval / 60)
        ];
    }

    public function addSchedules($schedules) {
        return array_merge($schedules, $this->schedules);
    }
}
