<?php

namespace Aura\Base;

class BaseCache {
    protected $prefix = 'aura_';
    protected $driver;
    protected $config;

    public function __construct($container) {
        $this->config = $container->get('config')->get('cache');
        $this->initializeDriver();
    }

    public function get($key, $default = null) {
        $value = $this->driver->get($this->prefix . $key);
        return $value !== false ? $value : $default;
    }

    public function set($key, $value, $ttl = 3600) {
        return $this->driver->set($this->prefix . $key, $value, $ttl);
    }

    public function delete($key) {
        return $this->driver->delete($this->prefix . $key);
    }

    public function flush() {
        return $this->driver->flush();
    }

    public function remember($key, $ttl, callable $callback) {
        $value = $this->get($key);

        if ($value !== null) {
            return $value;
        }

        $value = $callback();
        $this->set($key, $value, $ttl);

        return $value;
    }

    public function tags($tags) {
        if (!method_exists($this->driver, 'tags')) {
            throw new \Exception('Cache tags are not supported by this driver.');
        }

        return $this->driver->tags($tags);
    }

    protected function initializeDriver() {
        switch ($this->config['driver']) {
            case 'redis':
                $this->driver = new \Redis();
                $this->driver->connect(
                    $this->config['redis']['host'],
                    $this->config['redis']['port']
                );
                break;
            
            case 'memcached':
                $this->driver = new \Memcached();
                $this->driver->addServer(
                    $this->config['memcached']['host'],
                    $this->config['memcached']['port']
                );
                break;
            
            default:
                $this->driver = new \WP_Object_Cache();
        }
    }
}
