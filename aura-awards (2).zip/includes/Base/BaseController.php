<?php

namespace Aura\Base;

class BaseController {
    protected $container;
    protected $request;
    protected $response;

    public function __construct($container) {
        $this->container = $container;
        $this->request = $container->get('request');
        $this->response = $container->get('response');
    }

    protected function json($data, $status = 200) {
        return wp_send_json($data, $status);
    }

    protected function validate($data, $rules) {
        $validator = $this->container->get('validator');
        return $validator->validate($data, $rules);
    }

    protected function authorize($action, $model = null) {
        $user = wp_get_current_user();
        
        if (!$user->exists()) {
            return false;
        }

        $capability = "aura_{$action}";
        return current_user_can($capability);
    }

    protected function view($template, $data = []) {
        if (is_admin()) {
            return require plugin_dir_path(dirname(__FILE__)) . 'admin/views/' . $template . '.php';
        }
        return require plugin_dir_path(dirname(__FILE__)) . 'public/views/' . $template . '.php';
    }
}
