<?php

namespace Aura\Base;

abstract class BaseMiddleware {
    protected $container;
    protected $next;

    public function __construct($container) {
        $this->container = $container;
    }

    public function setNext($next) {
        $this->next = $next;
        return $next;
    }

    abstract public function handle($request);

    protected function validateToken($token) {
        if (empty($token)) {
            return false;
        }

        try {
            $decoded = jwt_decode($token, JWT_SECRET_KEY);
            return $decoded && $decoded->exp > time();
        } catch (\Exception $e) {
            return false;
        }
    }

    protected function getUser($token) {
        $decoded = jwt_decode($token, JWT_SECRET_KEY);
        return get_user_by('id', $decoded->user_id);
    }

    protected function isRateLimited($key, $limit = 60, $minutes = 1) {
        $cache = $this->container->get('cache');
        $current = (int) $cache->get($key, 0);
        
        if ($current >= $limit) {
            return true;
        }

        $cache->increment($key);
        $cache->expire($key, $minutes * 60);
        
        return false;
    }

    protected function respond($message, $status = 403) {
        return [
            'success' => false,
            'message' => $message,
            'status' => $status
        ];
    }
}
