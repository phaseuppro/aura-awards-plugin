<?php

namespace Aura\Base;

class BaseValidator {
    protected $data;
    protected $rules;
    protected $errors = [];
    protected $validated = [];

    protected $availableRules = [
        'required' => 'validateRequired',
        'email' => 'validateEmail',
        'min' => 'validateMin',
        'max' => 'validateMax',
        'numeric' => 'validateNumeric',
        'file' => 'validateFile',
        'image' => 'validateImage',
        'date' => 'validateDate',
        'url' => 'validateUrl',
        'unique' => 'validateUnique'
    ];

    public function validate($data, $rules) {
        $this->data = $data;
        $this->rules = $rules;
        $this->errors = [];
        $this->validated = [];

        foreach ($this->rules as $field => $fieldRules) {
            $this->validateField($field, $fieldRules);
        }

        return [
            'valid' => empty($this->errors),
            'errors' => $this->errors,
            'validated' => $this->validated
        ];
    }

    protected function validateField($field, $rules) {
        foreach ($rules as $rule => $parameter) {
            $method = $this->availableRules[$rule] ?? null;
            
            if ($method && method_exists($this, $method)) {
                $valid = $this->$method($field, $parameter);
                
                if (!$valid) {
                    $this->addError($field, $rule);
                } else {
                    $this->validated[$field] = $this->data[$field];
                }
            }
        }
    }

    protected function validateRequired($field) {
        return isset($this->data[$field]) && !empty($this->data[$field]);
    }

    protected function validateEmail($field) {
        return filter_var($this->data[$field], FILTER_VALIDATE_EMAIL);
    }

    protected function validateNumeric($field) {
        return is_numeric($this->data[$field]);
    }

    protected function validateMin($field, $min) {
        if (is_string($this->data[$field])) {
            return strlen($this->data[$field]) >= $min;
        }
        return $this->data[$field] >= $min;
    }

    protected function validateMax($field, $max) {
        if (is_string($this->data[$field])) {
            return strlen($this->data[$field]) <= $max;
        }
        return $this->data[$field] <= $max;
    }

    protected function addError($field, $rule) {
        $this->errors[$field][] = $this->getErrorMessage($field, $rule);
    }

    protected function getErrorMessage($field, $rule) {
        // Messages could be loaded from a language file
        return "The {$field} field failed {$rule} validation.";
    }
}
