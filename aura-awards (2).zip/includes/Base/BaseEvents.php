<?php

namespace Aura\Base;

class BaseEvents {
    protected $listeners = [];
    protected $container;
    protected $logger;

    public function __construct($container) {
        $this->container = $container;
        $this->logger = $container->get('logger');
        $this->loadEventConfig();
    }

    public function dispatch($event, $payload = []) {
        if (!isset($this->listeners[$event])) {
            return;
        }

        foreach ($this->listeners[$event] as $listener) {
            try {
                $listenerInstance = $this->resolveListener($listener);
                $listenerInstance->handle($payload);
                
                $this->logger->info("Event {$event} handled by " . get_class($listenerInstance), [
                    'payload' => $payload
                ]);
            } catch (\Exception $e) {
                $this->logger->error("Error handling event {$event}: " . $e->getMessage(), [
                    'listener' => $listener,
                    'payload' => $payload
                ]);
            }
        }
    }

    public function subscribe($event, $listener) {
        if (!isset($this->listeners[$event])) {
            $this->listeners[$event] = [];
        }
        $this->listeners[$event][] = $listener;
    }

    public function unsubscribe($event, $listener) {
        if (!isset($this->listeners[$event])) {
            return;
        }
        
        $this->listeners[$event] = array_filter(
            $this->listeners[$event],
            fn($l) => $l !== $listener
        );
    }

    protected function loadEventConfig() {
        $config = $this->container->get('config')->get('events');
        
        foreach ($config['listeners'] as $event => $listeners) {
            foreach ($listeners as $listener) {
                $this->subscribe($event, $listener);
            }
        }
    }

    protected function resolveListener($listener) {
        if (is_string($listener)) {
            return new $listener($this->container);
        }
        return $listener;
    }
}
