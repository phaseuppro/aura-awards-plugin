<?php

namespace Aura\Base;

class BaseNotification {
    protected $container;
    protected $mailer;
    protected $config;
    protected $templates = [];

    public function __construct($container) {
        $this->container = $container;
        $this->mailer = $container->get('mailer');
        $this->config = $container->get('config')->get('notifications');
        $this->loadTemplates();
    }

    public function send($type, $recipient, $data = []) {
        if (!isset($this->templates[$type])) {
            throw new \Exception("Notification template not found: {$type}");
        }

        $template = $this->templates[$type];
        $content = $this->parseTemplate($template, $data);

        return $this->mailer->send([
            'to' => $recipient,
            'subject' => $template['subject'],
            'body' => $content,
            'headers' => $this->getHeaders()
        ]);
    }

    public function notify($users, $type, $data = []) {
        foreach ($users as $user) {
            $this->send($type, $user->user_email, array_merge(
                $data,
                ['user' => $user]
            ));
        }
    }

    protected function loadTemplates() {
        $this->templates = $this->config['email'];
    }

    protected function parseTemplate($template, $data) {
        $content = file_get_contents(
            plugin_dir_path(dirname(__FILE__)) . 'templates/' . $template['template'] . '.php'
        );

        return $this->replacePlaceholders($content, $data);
    }

    protected function replacePlaceholders($content, $data) {
        foreach ($data as $key => $value) {
            $content = str_replace(
                ['{{' . $key . '}}', '{{ ' . $key . ' }}'],
                $value,
                $content
            );
        }
        return $content;
    }

    protected function getHeaders() {
        return [
            'Content-Type: text/html; charset=UTF-8',
            'From: ' . get_option('blogname') . ' <' . get_option('admin_email') . '>'
        ];
    }
}
