<?php if (!defined('ABSPATH')) exit; ?>

<div class="aura-dashboard-wrapper">
    <div class="aura-stats-grid">
        <!-- Statistics Overview -->
        <div class="stat-box">
            <h3>Total Submissions</h3>
            <div class="stat-number"><?php echo esc_html($total_submissions); ?></div>
        </div>
        
        <div class="stat-box">
            <h3>Active Awards</h3>
            <div class="stat-number"><?php echo esc_html($active_awards); ?></div>
        </div>
        
        <div class="stat-box">
            <h3>Registered Photographers</h3>
            <div class="stat-number"><?php echo esc_html($total_photographers); ?></div>
        </div>
        
        <div class="stat-box">
            <h3>Pending Judgments</h3>
            <div class="stat-number"><?php echo esc_html($pending_judgments); ?></div>
        </div>
    </div>

    <div class="aura-recent-activity">
        <h2>Recent Activity</h2>
        <table class="wp-list-table widefat fixed striped">
            <thead>
                <tr>
                    <th>Date</th>
                    <th>User</th>
                    <th>Action</th>
                    <th>Details</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($recent_activities as $activity): ?>
                <tr>
                    <td><?php echo esc_html($activity->date); ?></td>
                    <td><?php echo esc_html($activity->user); ?></td>
                    <td><?php echo esc_html($activity->action); ?></td>
                    <td><?php echo esc_html($activity->details); ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>

    <div class="aura-quick-actions">
        <h2>Quick Actions</h2>
        <div class="action-buttons">
            <a href="<?php echo admin_url('admin.php?page=aura-awards&tab=submissions&action=new'); ?>" class="button button-primary">Create New Award</a>
            <a href="<?php echo admin_url('admin.php?page=aura-awards&tab=judging'); ?>" class="button button-secondary">Review Submissions</a>
            <a href="<?php echo admin_url('admin.php?page=aura-awards&tab=settings'); ?>" class="button button-secondary">Configure Settings</a>
        </div>
    </div>
</div>
