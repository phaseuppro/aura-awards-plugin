<?php
namespace Aura\Controllers;

class SubmissionController {
    private $service;
    private $container;

    public function __construct($container) {
        $this->container = $container;
        $this->service = $container->get('SubmissionService');
        $this->registerHooks();
    }

    private function registerHooks() {
        add_action('init', [$this, 'registerPostType']);
        add_action('wp_ajax_submit_photo', [$this, 'handleSubmission']);
    }

    public function registerPostType() {
        register_post_type('submission', [
            'public' => true,
            'label'  => 'Submissions',
            'supports' => ['title', 'thumbnail'],
            'menu_icon' => 'dashicons-format-image'
        ]);
    }
}
