<?php
namespace Aura\Controllers;

class AdminController {
    private $service;
    private $container;

    public function __construct($container) {
        $this->container = $container;
        $this->service = $container->get('AdminService');
        $this->registerHooks();
    }

    private function registerHooks() {
        add_action('admin_menu', [$this, 'addAdminMenus']);
        add_action('admin_init', [$this, 'registerSettings']);
        add_action('admin_enqueue_scripts', [$this, 'enqueueAdminAssets']);
    }

    public function addAdminMenus() {
        add_menu_page(
            'Aura Awards',
            'Aura Awards',
            'manage_options',
            'aura-awards',
            [$this, 'renderMainDashboard'],
            'dashicons-awards',
            30
        );

        add_submenu_page(
            'aura-awards',
            'Submissions',
            'Submissions',
            'manage_options',
            'aura-submissions',
            [$this, 'renderSubmissions']
        );

        add_submenu_page(
            'aura-awards',
            'Settings',
            'Settings',
            'manage_options',
            'aura-settings',
            [$this, 'renderSettings']
        );
    }

    public function enqueueAdminAssets($hook) {
        // Only load on plugin pages
        if (strpos($hook, 'aura-awards') === false) {
            return;
        }

        wp_enqueue_style(
            'aura-admin-styles',
            AURA_PLUGIN_URL . 'assets/css/admin.css',
            [],
            AURA_VERSION
        );

        wp_enqueue_script(
            'aura-admin-scripts',
            AURA_PLUGIN_URL . 'assets/js/admin.js',
            ['jquery'],
            AURA_VERSION,
            true
        );
    }

    public function renderMainDashboard() {
        $active_tab = isset($_GET['tab']) ? $_GET['tab'] : 'dashboard';
        $stats = $this->service->getDashboardStats();
        $recent_activities = $this->service->getRecentActivity();
        include AURA_PLUGIN_DIR . 'views/admin/main-dashboard.php';
    }

    public function renderSubmissions() {
        $submissions = $this->service->getAllSubmissions();
        include AURA_PLUGIN_DIR . 'views/admin/submissions-tab.php';
    }

    public function renderSettings() {
        include AURA_PLUGIN_DIR . 'views/admin/settings-tab.php';
    }

    public function registerSettings() {
        register_setting('aura_awards_options', 'aura_public_voting');
        register_setting('aura_awards_options', 'aura_submission_credits');
        register_setting('aura_awards_options', 'aura_max_submissions');
        register_setting('aura_awards_options', 'aura_required_judges');
        register_setting('aura_awards_options', 'aura_scoring_system');
        register_setting('aura_awards_options', 'aura_admin_email');
        register_setting('aura_awards_options', 'aura_submission_email');
    }
}
