<?php
namespace Aura\Base;

class BaseEvents {
    private $events = [];

    public function on($event, $callback) {
        if (!isset($this->events[$event])) {
            $this->events[$event] = [];
        }
        $this->events[$event][] = $callback;
    }

    public function trigger($event, $data = []) {
        if (isset($this->events[$event])) {
            foreach ($this->events[$event] as $callback) {
                call_user_func($callback, $data);
            }
        }
    }
}