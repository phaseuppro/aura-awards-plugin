<?php
namespace Aura\Base;

class BaseUploader {
    private $allowed_types = ['image/jpeg', 'image/png'];
    private $max_size = 5242880; // 5MB

    public function upload($file, $destination) {
        if (!in_array($file['type'], $this->allowed_types)) {
            throw new \Exception('Invalid file type');
        }

        if ($file['size'] > $this->max_size) {
            throw new \Exception('File too large');
        }

        $upload_path = AURA_PLUGIN_DIR . 'uploads/' . $destination;
        if (!is_dir($upload_path)) {
            mkdir($upload_path, 0755, true);
        }

        $filename = uniqid() . '-' . sanitize_file_name($file['name']);
        $filepath = $upload_path . '/' . $filename;

        if (move_uploaded_file($file['tmp_name'], $filepath)) {
            return $filename;
        }

        throw new \Exception('Upload failed');
    }
}