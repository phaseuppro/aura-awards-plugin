<?php
namespace Aura\Base;

class Database {
    public static function createTables() {
        global $wpdb;
        $charset_collate = $wpdb->get_charset_collate();

        $sql = [
            "CREATE TABLE IF NOT EXISTS {$wpdb->prefix}aura_submissions (
                id bigint(20) NOT NULL AUTO_INCREMENT,
                user_id bigint(20) NOT NULL,
                award_id bigint(20) NOT NULL,
                image_path varchar(255) NOT NULL,
                status varchar(20) DEFAULT 'pending',
                created_at datetime DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY  (id)
            ) $charset_collate;",

            "CREATE TABLE IF NOT EXISTS {$wpdb->prefix}aura_judgments (
                id bigint(20) NOT NULL AUTO_INCREMENT,
                submission_id bigint(20) NOT NULL,
                judge_id bigint(20) NOT NULL,
                score int(11) NOT NULL,
                feedback text,
                created_at datetime DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY  (id)
            ) $charset_collate;",

            "CREATE TABLE IF NOT EXISTS {$wpdb->prefix}aura_credits (
                id bigint(20) NOT NULL AUTO_INCREMENT,
                user_id bigint(20) NOT NULL,
                credits int(11) NOT NULL,
                transaction_type varchar(20) NOT NULL,
                created_at datetime DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY  (id)
            ) $charset_collate;"
        ];

        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        foreach($sql as $query) {
            dbDelta($query);
        }
    }
}
