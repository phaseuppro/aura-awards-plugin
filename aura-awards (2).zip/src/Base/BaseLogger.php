<?php
namespace Aura\Base;

class BaseLogger {
    public function log($message, $level = 'info') {
        $log_file = AURA_PLUGIN_DIR . 'logs/aura-' . date('Y-m-d') . '.log';
        $timestamp = date('Y-m-d H:i:s');
        $log_message = "[$timestamp] [$level] $message\n";
        error_log($log_message, 3, $log_file);
    }
}