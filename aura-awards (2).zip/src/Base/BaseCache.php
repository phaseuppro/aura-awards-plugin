<?php
namespace Aura\Base;

class BaseCache {
    private $cache = [];
    private $expiry = [];
    
    public function set($key, $value, $expiry = 3600) {
        $this->cache[$key] = $value;
        $this->expiry[$key] = time() + $expiry;
    }
    
    public function get($key) {
        if (isset($this->cache[$key]) && time() < $this->expiry[$key]) {
            return $this->cache[$key];
        }
        return null;
    }
}