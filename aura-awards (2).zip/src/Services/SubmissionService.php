<?php
namespace Aura\Services;

class SubmissionService {
    private $container;
    private $uploader;

    public function __construct($container) {
        $this->container = $container;
        $this->uploader = $container->get('uploader');
    }

    public function submitPhoto($data, $file) {
        $filename = $this->uploader->upload($file, 'submissions');
        
        return wp_insert_post([
            'post_type' => 'submission',
            'post_title' => $data['title'],
            'post_status' => 'pending',
            'meta_input' => [
                '_photo_file' => $filename,
                '_award_id' => $data['award_id']
            ]
        ]);
    }
}
