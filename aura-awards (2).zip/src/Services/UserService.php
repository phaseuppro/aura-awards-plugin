<?php
namespace Aura\Services;

class JudgingService {
    private $container;

    public function __construct($container) {
        $this->container = $container;
    }

    public function submitScore($submission_id, $judge_id, $score, $feedback) {
        return add_post_meta($submission_id, '_judge_score', [
            'judge_id' => $judge_id,
            'score' => $score,
            'feedback' => $feedback,
            'date' => current_time('mysql')
        ]);
    }

    public function getSubmissionScores($submission_id) {
        return get_post_meta($submission_id, '_judge_score');
    }
}
