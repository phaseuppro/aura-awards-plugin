<?php
namespace Aura\Services;

class AdminService {
    private $container;

    public function __construct($container) {
        $this->container = $container;
    }

    public function getDashboardStats() {
        return [
            'total_submissions' => $this->getTotalSubmissions(),
            'active_awards' => $this->getActiveAwardsCount(),
            'total_photographers' => $this->getTotalPhotographers(),
            'pending_judgments' => $this->getPendingJudgments()
        ];
    }

    public function getTotalSubmissions() {
        return wp_count_posts('submission')->publish;
    }

    public function getActiveAwardsCount() {
        return wp_count_posts('award')->publish;
    }

    public function getTotalPhotographers() {
        return count(get_users(['role' => 'photographer']));
    }

    public function getPendingJudgments() {
        return wp_count_posts('submission')->pending;
    }

    public function getRecentActivity($limit = 10) {
        global $wpdb;
        return $wpdb->get_results(
            $wpdb->prepare(
                "SELECT * FROM {$wpdb->prefix}aura_activity_log 
                ORDER BY date DESC 
                LIMIT %d",
                $limit
            )
        );
    }

    public function savePluginSettings($settings) {
        foreach ($settings as $key => $value) {
            update_option('aura_' . $key, $value);
        }
        return true;
    }
}
