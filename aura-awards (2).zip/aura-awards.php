<?php
/**
 * Plugin Name: AURA AWARDS
 * Description: Professional photography awards and ranking system
 * Version: 1.0.0
 * Author: Your Name
 * Text Domain: aura-awards
 */

if (!defined('ABSPATH')) {
    exit;
}

define('AURA_VERSION', '1.0.0');
define('AURA_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('AURA_PLUGIN_URL', plugin_dir_url(__FILE__));

require_once __DIR__ . '/vendor/autoload.php';

function aura_awards_activate() {
    require_once AURA_PLUGIN_DIR . 'src/Base/Database.php';
    \Aura\Base\Database::createTables();
    
    add_role('photographer', 'Photographer', [
        'read' => true,
        'upload_files' => true
    ]);
    
    flush_rewrite_rules();
}

register_activation_hook(__FILE__, 'aura_awards_activate');

add_action('plugins_loaded', function() {
    if (!class_exists('BuddyPress')) {
        add_action('admin_notices', function() {
            echo '<div class="error"><p>AURA AWARDS requires BuddyPress to be installed and active.</p></div>';
        });
        return;
    }
    
    require_once AURA_PLUGIN_DIR . 'includes/class-member-types.php';
    require_once AURA_PLUGIN_DIR . 'includes/class-profile-fields.php';
    require_once AURA_PLUGIN_DIR . 'includes/class-activity-stream.php';
    require_once AURA_PLUGIN_DIR . 'includes/class-submission-handler.php';
    require_once AURA_PLUGIN_DIR . 'includes/class-voting-system.php';
    require_once AURA_PLUGIN_DIR . 'includes/class-badge-manager.php';
    require_once AURA_PLUGIN_DIR . 'includes/class-ranking-system.php';
    require_once AURA_PLUGIN_DIR . 'includes/class-credit-system.php';
    require_once AURA_PLUGIN_DIR . 'admin/class-admin-interface.php';
});
