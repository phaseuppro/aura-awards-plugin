<?php

use DI\ContainerBuilder;
use Aura\Core\Services;
use Aura\Core\Repositories;
use Aura\Core\Controllers;

$containerBuilder = new ContainerBuilder();

$containerBuilder->addDefinitions([
    // Services
    Services\AwardService::class => \DI\create()
        ->constructor(
            \DI\get(Repositories\AwardRepository::class),
            \DI\get(Services\NotificationService::class)
        ),

    Services\SubmissionService::class => \DI\create()
        ->constructor(
            \DI\get(Repositories\SubmissionRepository::class),
            \DI\get(Services\ImageService::class)
        ),

    Services\JudgingService::class => \DI\create()
        ->constructor(
            \DI\get(Repositories\JudgingRepository::class),
            \DI\get(Services\ScoringService::class)
        ),

    // Repositories
    Repositories\AwardRepository::class => \DI\create(),
    Repositories\SubmissionRepository::class => \DI\create(),
    Repositories\JudgingRepository::class => \DI\create(),
    Repositories\UserRepository::class => \DI\create(),

    // Controllers
    Controllers\AwardController::class => \DI\create()
        ->constructor(
            \DI\get(Services\AwardService::class)
        ),

    Controllers\SubmissionController::class => \DI\create()
        ->constructor(
            \DI\get(Services\SubmissionService::class)
        ),

    Controllers\JudgingController::class => \DI\create()
        ->constructor(
            \DI\get(Services\JudgingService::class)
        ),

    // Utilities
    'logger' => \DI\factory(function() {
        return new \Monolog\Logger('aura-awards');
    }),

    'cache' => function() {
        return new \Symfony\Component\Cache\Adapter\FilesystemAdapter();
    },
]);

return $containerBuilder->build();
