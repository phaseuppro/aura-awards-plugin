<?php

return [
    'roles' => [
        'photographer' => [
            'label' => 'Photographer',
            'capabilities' => [
                'read' => true,
                'upload_files' => true,
                'edit_posts' => true,
                'aura_submit_photos' => true,
                'aura_view_own_submissions' => true,
                'aura_edit_own_submissions' => true
            ]
        ],
        'judge' => [
            'label' => 'Judge',
            'capabilities' => [
                'read' => true,
                'aura_judge_submissions' => true,
                'aura_view_all_submissions' => true,
                'aura_provide_feedback' => true
            ]
        ],
        'admin' => [
            'label' => 'Awards Administrator',
            'capabilities' => [
                'read' => true,
                'manage_options' => true,
                'aura_manage_awards' => true,
                'aura_manage_submissions' => true,
                'aura_manage_judges' => true,
                'aura_manage_photographers' => true,
                'aura_export_data' => true,
                'aura_import_data' => true
            ]
        ]
    ],
    
    'capabilities' => [
        'submission' => [
            'create' => 'aura_submit_photos',
            'read' => 'aura_view_submissions',
            'update' => 'aura_edit_submissions',
            'delete' => 'aura_delete_submissions'
        ],
        'judging' => [
            'judge' => 'aura_judge_submissions',
            'feedback' => 'aura_provide_feedback'
        ],
        'awards' => [
            'manage' => 'aura_manage_awards',
            'assign' => 'aura_assign_awards'
        ],
        'settings' => [
            'manage' => 'manage_options'
        ]
    ]
];
