<?php

return [
    'name' => 'AURA Awards',
    'version' => '1.0.0',
    'min_wp_version' => '5.8',
    'min_php_version' => '7.4',
    
    'paths' => [
        'plugin' => plugin_dir_path(dirname(__FILE__)),
        'assets' => plugin_dir_url(dirname(__FILE__)) . 'dist/',
        'templates' => plugin_dir_path(dirname(__FILE__)) . 'templates/',
        'languages' => plugin_dir_path(dirname(__FILE__)) . 'languages/'
    ],
    
    'database' => [
        'tables' => [
            'submissions' => 'aura_submissions',
            'awards' => 'aura_awards',
            'judging' => 'aura_judging',
            'categories' => 'aura_categories'
        ],
        'version' => '1.0.0'
    ],
    
    'features' => [
        'submissions' => true,
        'judging' => true,
        'awards' => true,
        'galleries' => true,
        'social_sharing' => true,
        'export' => true
    ],
    
    'email' => [
        'from_name' => 'AURA Awards',
        'from_email' => 'noreply@example.com',
        'templates_dir' => 'emails/'
    ],
    
    'images' => [
        'max_size' => 10 * 1024 * 1024, // 10MB
        'allowed_types' => ['jpg', 'jpeg', 'png'],
        'max_dimensions' => [
            'width' => 5000,
            'height' => 5000
        ],
        'thumbnails' => [
            'small' => [150, 150],
            'medium' => [300, 300],
            'large' => [800, 800]
        ]
    ],
    
    'cache' => [
        'enabled' => true,
        'duration' => 3600,
        'prefix' => 'aura_'
    ],
    
    'api' => [
        'enabled' => true,
        'rate_limit' => 60, // requests per minute
        'timeout' => 30
    ]
];
