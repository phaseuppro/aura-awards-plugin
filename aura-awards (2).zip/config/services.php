<?php

return [
    'storage' => [
        'driver' => 'local',
        'uploads_dir' => wp_upload_dir()['basedir'] . '/aura-awards',
        'uploads_url' => wp_upload_dir()['baseurl'] . '/aura-awards',
        
        's3' => [
            'key' => env('AWS_ACCESS_KEY_ID'),
            'secret' => env('AWS_SECRET_ACCESS_KEY'),
            'region' => env('AWS_REGION', 'us-west-2'),
            'bucket' => env('AWS_BUCKET'),
            'url' => env('AWS_URL'),
            'endpoint' => env('AWS_ENDPOINT'),
        ]
    ],
    
    'mail' => [
        'driver' => 'smtp',
        'host' => env('SMTP_HOST', 'smtp.mailtrap.io'),
        'port' => env('SMTP_PORT', 2525),
        'username' => env('SMTP_USER'),
        'password' => env('SMTP_PASS'),
        'encryption' => env('SMTP_ENCRYPTION', 'tls')
    ],
    
    'cache' => [
        'driver' => 'file',
        'path' => WP_CONTENT_DIR . '/cache/aura-awards',
        
        'redis' => [
            'host' => env('REDIS_HOST', '127.0.0.1'),
            'port' => env('REDIS_PORT', 6379),
            'password' => env('REDIS_PASSWORD'),
            'database' => env('REDIS_DB', 0)
        ]
    ],
    
    'queue' => [
        'driver' => 'database',
        'table' => 'aura_jobs',
        'failed_table' => 'aura_failed_jobs',
        
        'redis' => [
            'host' => env('REDIS_HOST', '127.0.0.1'),
            'port' => env('REDIS_PORT', 6379),
            'password' => env('REDIS_PASSWORD'),
            'database' => env('REDIS_DB', 0)
        ]
    ],
    
    'logging' => [
        'driver' => 'file',
        'path' => WP_CONTENT_DIR . '/logs/aura-awards.log',
        'level' => env('LOG_LEVEL', 'debug'),
        'days' => 14
    ]
];
