=== AURA AWARDS ===
Contributors: yourname
Tags: photography, awards, contest, ranking, badges
Requires at least: 5.0
Tested up to: 6.4
Stable tag: 1.0.0
Requires PHP: 7.4
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Professional photography awards and ranking system for WordPress.

== Description ==

AURA AWARDS is a comprehensive photography awards platform that enables photographers to submit their work, receive professional evaluations, earn badges, and compete in seasonal rankings.

Key Features:

* Professional submission system with image validation
* Advanced judging interface with multiple criteria
* Dynamic badge system with automatic application
* Seasonal and category-based rankings
* Credit-based submission system
* BuddyPress integration for social features
* Comprehensive activity tracking
* Export rankings to CSV/PDF

== Installation ==

1. Upload the plugin files to `/wp-content/plugins/aura-awards`
2. Activate the plugin through the 'Plugins' screen in WordPress
3. Install and activate BuddyPress
4. Configure plugin settings under "AURA AWARDS" menu

== Frequently Asked Questions ==

= What are the minimum image requirements? =

Images must be at least 2028px on the shortest side and no larger than 4000px on the longest side. Maximum file size is 5MB.

= How does the credit system work? =

Users can purchase credit packages to submit their photos. Different packages offer varying numbers of submission credits at different price points.

== Changelog ==

= 1.0.0 =
* Initial release

== Upgrade Notice ==

= 1.0.0 =
Initial release of AURA AWARDS

== Screenshots ==

1. Dashboard overview
2. Submission interface
3. Judging panel
4. Rankings display
5. Badge management

== Requirements ==

* WordPress 5.0 or higher
* BuddyPress 10.0 or higher
* PHP 7.4 or higher
* MySQL 5.6 or higher
