jQuery(document).ready(function($) {
    // Dashboard Statistics Refresh
    function refreshStats() {
        $.ajax({
            url: ajaxurl,
            data: {
                action: 'refresh_dashboard_stats'
            },
            success: function(response) {
                if (response.success) {
                    updateDashboardStats(response.data);
                }
            }
        });
    }

    // Submissions Filtering
    $('#filter-submissions').on('click', function() {
        var award = $('#award_filter').val();
        var status = $('#status_filter').val();

        $.ajax({
            url: ajaxurl,
            data: {
                action: 'filter_submissions',
                award: award,
                status: status
            },
            success: function(response) {
                if (response.success) {
                    $('#submissions-list').html(response.data);
                }
            }
        });
    });

    // Judging System
    $('.score-slider').on('input', function() {
        $(this).siblings('.score-value').text($(this).val());
    });

    $('.submit-score').on('click', function() {
        var card = $(this).closest('.submission-card');
        var submissionId = card.data('id');
        var score = card.find('.score-slider').val();
        var feedback = card.find('.feedback-text').val();

        $.ajax({
            url: ajaxurl,
            method: 'POST',
            data: {
                action: 'submit_judgment',
                submission_id: submissionId,
                score: score,
                feedback: feedback
            },
            success: function(response) {
                if (response.success) {
                    card.fadeOut();
                }
            }
        });
    });

    // Initialize tooltips
    $('.aura-tooltip').tooltip();

    // Auto-refresh dashboard stats every 5 minutes
    setInterval(refreshStats, 300000);
});
